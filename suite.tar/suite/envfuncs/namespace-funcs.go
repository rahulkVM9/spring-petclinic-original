// Copyright 2021 VMware, Inc. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

package envfuncs

import (
	"context"
	"fmt"
	"log"

	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubectl/kubectlCmds"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubectl/kubectl_libs"
	"sigs.k8s.io/e2e-framework/pkg/env"
	"sigs.k8s.io/e2e-framework/pkg/envconf"
)

func CreateNamespaces(namespaces []string) env.Func {
	return func(ctx context.Context, cfg *envconf.Config) (context.Context, error) {
		log.Printf("creating namespaces %s", namespaces)

		// create
		for _, namespace := range namespaces {
			err := kubectlCmds.KubectlCreateNamespace(namespace)
			if err != nil {
				return ctx, fmt.Errorf("error while creating namespace %s", namespace)
			}
		}

		return ctx, nil
	}
}

func CreateNamespacesIfNotExists(namespaces []string) env.Func {
	return func(ctx context.Context, cfg *envconf.Config) (context.Context, error) {
		log.Printf("creating namespaces %s", namespaces)

		// create
		for _, namespace := range namespaces {
			err := kubectl_libs.KubectlCreateNamespaceIfNotExists(namespace)
			if err != nil {
				return ctx, fmt.Errorf("error while creating namespace %s", namespace)
			}
		}

		return ctx, nil
	}
}

func DeleteNamespaces(namespaces []string) env.Func {
	return func(ctx context.Context, cfg *envconf.Config) (context.Context, error) {
		log.Printf("deleting namespaces %s", namespaces)

		// delete
		for _, namespace := range namespaces {
			err := kubectlCmds.KubectlDeleteNamespace(namespace)
			if err != nil {
				return ctx, fmt.Errorf("error while deleting namespace %s", namespace)
			}
		}

		return ctx, nil
	}
}

func SetupDeveloperNamespace(file string, namespace string) env.Func {
	return func(ctx context.Context, cfg *envconf.Config) (context.Context, error) {
		log.Printf("setting up developer namespace %s", namespace)

		// apply developer namespace
		err := kubectlCmds.KubectlApplyConfiguration(file, namespace)
		if err != nil {
			return ctx, fmt.Errorf("error while setting up developer namespace %s", namespace)
		}

		return ctx, nil
	}
}

func DeleteDeveloperNamespace(file string, namespace string) env.Func {
	return func(ctx context.Context, cfg *envconf.Config) (context.Context, error) {
		log.Printf("deleting developer namespace %s", namespace)

		// delete developer namespace
		err := kubectlCmds.KubectlDeleteConfiguration(file, namespace)
		if err != nil {
			return ctx, fmt.Errorf("error while deleting developer namespace %s", namespace)
		}

		return ctx, nil
	}
}
