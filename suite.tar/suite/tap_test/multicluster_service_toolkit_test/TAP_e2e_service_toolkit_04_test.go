//go:build all || multicluster_service_toolkit || service_toolkit_dedicated_cluster

package multicluster_service_toolkit_test

import (
	"testing"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"path/filepath"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils"
)

func TestServicetoolkitWithDedicatedCluster(t *testing.T) {
	t.Log("************** TestCase START: TestServicetoolkitWithDedicatedCluster **************")
	rabbitmq_cluster_intance_file:= filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "rabbitmq-clusterinstance.yaml")
	rabbitmq_cluster_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "rabbitmq-cluster.yaml")
	resource_claims_cross_namepace_policy_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "rmq-claim-policy.yaml")
	multicluster_binding_sample:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "multi-cluster-binding-sample-workload.yaml")
	testenv.Test(t,
		// Switch to Service cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.ServiceClusterContext),
		common_features.InstallIndividualPackage(t,  "services-toolkit", suiteConfig.ServiceToolkit.PackageRepository, suiteConfig.PackageRepository.Namespace, "", ""),

		// Link Workload cluster and service cluster
		common_features.LinkCluster(t, suiteConfig.Multicluster.WorkloadClusterContext, suiteConfig.Multicluster.ServiceClusterContext),

		common_features.InstallAndDeployRmqOperator(t, suiteConfig.ServiceToolkit.Name, suiteConfig.ServiceToolkit.RabbitMQOperatorFile),
		common_features.ListInstalledOperator(t, "rabbitmqclusters.rabbitmq.com"),

		// // Switch to Workload cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.WorkloadClusterContext),
		common_features.CreateNamespace(t, "service-instances"),

		// Switch to Service cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.ServiceClusterContext),
		common_features.CreateNamespace(t, "service-instances"),

		common_features.FedrateCluster(t, suiteConfig.Multicluster.WorkloadClusterContext, suiteConfig.Multicluster.ServiceClusterContext, "service-instances", "rabbitmq.com", "v1beta1", "rabbitmqclusters"),
		common_features.GetApiResources(t),

		// Switch to Workload cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.WorkloadClusterContext),
		common_features.ApplyKubectlConfigurationFile(t, rabbitmq_cluster_intance_file, "default"),
		common_features.ServiceClassesList(t),
		common_features.ApplyKubectlConfigurationFile(t, rabbitmq_cluster_file, "service-instances"),
		common_features.VerifyRabbitmqClustersResources(t, rabbitmq_cluster_file, "service-instances"),

		// Switch to Service cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.ServiceClusterContext),
		common_features.VerifyPodStatus(t, "service-instances"),

		// Switch to Workload cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.WorkloadClusterContext),
		// Apply Cross namespace policy
		common_features.ApplyKubectlConfigurationFile(t, resource_claims_cross_namepace_policy_file, "service-instances"),
		common_features.CreateServiceClaimWithInput(t, "projected-rmq-claim", "projected-rmq", "service-instances", "RabbitmqCluster", "rabbitmq.com/v1beta1"),

		common_features.VerifyServiceClaimStatus(t, "projected-rmq-claim"),

		// Create Sample Multicluster Binding workload 
		common_features.TanzuDeployWorkload(t, multicluster_binding_sample, "default"),

		// Verify Workload
		common_features.VerifyBuildStatus(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadName, suiteConfig.ServiceToolkit.BuildNameSuffix,"default"),
		common_features.VerifyRevisionStatus(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadName, "default"),
		common_features.VerifyKsvcStatus(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadName, "default"),
		common_features.GetKsvcUrl(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadName, "default"),

		common_features.VerifyWorkloadResponse(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadURL, suiteConfig.ServiceToolkit.Message, ""),
		common_features.TanzuDeleteWorkload(t, suiteConfig.ServiceToolkit.MulticlusterWorkloadName, "default"),
		common_features.TanzuDeleteServiceClaim(t, "projected-rmq-claim", "default"),
		// Switch to Service cluster
		common_features.ChangeContext(t, suiteConfig.Multicluster.ServiceClusterContext),
		common_features.DeleteApp(t, suiteConfig.ServiceToolkit.Name),
		common_features.DeletePackage(t, "services-toolkit", suiteConfig.PackageRepository.Namespace),
	)
	t.Log("************** TestCase END: TestServicetoolkitWithDedicatedCluster **************")
}
