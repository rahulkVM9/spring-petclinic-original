//go:build singlecluster_tap_install_testing

package singlecluster_tap_install

import (
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"testing"
)

func TestInstallTestingSupplyChain(t *testing.T) {
	t.Log("************** TestCase START: TestInstallTestingSupplyChain **************")
	testenv.Test(t,
		common_features.UpdateTapProfileSupplyChain(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Version, "full", "testing", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.SpringPetclinicPipeline.YamlFile, outerloopConfig.Namespace),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.Mysql.YamlFile, outerloopConfig.Namespace),
	)
	t.Log("************** TestCase END: TestInstallTestingSupplyChain **************")
}
