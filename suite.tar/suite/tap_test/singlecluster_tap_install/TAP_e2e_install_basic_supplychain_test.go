//go:build singlecluster_tap_install_basic

package singlecluster_tap_install

import (
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"testing"
)

func TestInstallBasicSupplyChain(t *testing.T) {
	t.Log("************** TestCase START: TestInstallBasicSupplyChain **************")
	testenv.Test(t,
		common_features.UpdateTapProfileSupplyChain(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Version, "full", "basic", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.Mysql.YamlFile, outerloopConfig.Namespace),
	)
	t.Log("************** TestCase END: TestInstallBasicSupplyChain **************")
}
