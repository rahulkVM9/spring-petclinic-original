//go:build all || multicluster_upgrade

package multicluster_upgrade

import (
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_tests"
	"path/filepath"
	"testing"
)

func TestTapUpgrade(t *testing.T) {
	t.Log("************** TestCase START: TestTapUpgrade **************")
	developerNamespaceFile := filepath.Join("../../resources/suite/developer-namespace.yaml")
	for _, upgradeMetadata := range suiteConfig.UpgradeVersions {

		t.Logf("upgrade from %s to %s", upgradeMetadata.Image, upgradeMetadata.UpgradeImage)

		t.Logf("Adding tanzu repo and tap package %s in view cluster", upgradeMetadata.Image)
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.ViewClusterContext),
			common_features.AddPackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.Image, suiteConfig.Tap.Namespace),
			common_features.InstallPackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, upgradeMetadata.TapVersion, suiteConfig.Tap.Namespace, suiteConfig.Multicluster.ViewWithMetadataStoreTapValuesFile, suiteConfig.Tap.PollTimeout),
			common_features.UpdateDomainRecords(t),
		)

		t.Logf("Adding tanzu repo and tap package %s in build cluster", upgradeMetadata.Image)
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
			common_features.AddPackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.Image, suiteConfig.Tap.Namespace),
			common_features.InstallPackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, upgradeMetadata.TapVersion, suiteConfig.Tap.Namespace, suiteConfig.Multicluster.BuildTapValuesFile, suiteConfig.Tap.PollTimeout),
			common_features.UpdateMetadataStoreScanning(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, upgradeMetadata.TapVersion, "build", "testing_scanning", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout, outerloopConfig.MetadataStore.Domain, suiteConfig.Multicluster.ViewClusterContext, suiteConfig.Multicluster.BuildClusterContext, outerloopConfig.MetadataStore.Namespace),
			common_features.ApplyKubectlConfigurationFile(t, developerNamespaceFile, suiteConfig.CreateNamespaces[0]),
		)

		t.Logf("Adding tanzu repo and tap package %s in run cluster", upgradeMetadata.Image)
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
			common_features.AddPackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.Image, suiteConfig.Tap.Namespace),
			common_features.InstallPackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, upgradeMetadata.TapVersion, suiteConfig.Tap.Namespace, suiteConfig.Multicluster.RunTapValuesFile, suiteConfig.Tap.PollTimeout),
			common_features.ApplyKubectlConfigurationFile(t, developerNamespaceFile, suiteConfig.CreateNamespaces[0]),
		)

		// crud tests
		t.Log("************** Starting outerloop test 1 **************")
		common_tests.Outerloop_scanning_supplychain_test(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)

		// upgrading tap repo in all 3 clusters
		t.Log("************** Updating tanzu repository in all 3 clusters **************")
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.ViewClusterContext),
			common_features.UpdatePackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.UpgradeImage, suiteConfig.Tap.Namespace),
			common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
			common_features.UpdatePackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.UpgradeImage, suiteConfig.Tap.Namespace),
			common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
			common_features.UpdatePackageRepository(t, suiteConfig.PackageRepository.Name, upgradeMetadata.UpgradeImage, suiteConfig.Tap.Namespace),
		)

		// upgrading tap in run cluster
		t.Log("************** Updating tap in run cluster **************")
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
			common_features.UpdateTapVersion(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Namespace, suiteConfig.Multicluster.RunTapValuesFile, upgradeMetadata.UpgradeTapVersion, suiteConfig.Tap.PollTimeout),
		)

		//verify old workloads and delete
		common_tests.Outerloop_scanning_supplychain_verify(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		common_tests.Outerloop_scanning_supplychain_cleanup(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		t.Log("************** Ending outerloop test 1 **************")

		//new workload tests
		t.Log("************** Starting outerloop test 2 **************")
		common_tests.Outerloop_scanning_supplychain_test(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)

		//upgrading tap in build cluster
		t.Log("************** Updating tap in build cluster **************")
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
			common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.ScanPolicy.YamlFile, outerloopConfig.Namespace),
			common_features.UpdateMetadataStoreScanning(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, upgradeMetadata.UpgradeTapVersion, "build", "testing_scanning", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout, outerloopConfig.MetadataStore.Domain, suiteConfig.Multicluster.ViewClusterContext, suiteConfig.Multicluster.BuildClusterContext, outerloopConfig.MetadataStore.Namespace),
			common_features.VerifyBuildStatusAfterUpdate(t, outerloopConfig.Workload.Name, outerloopConfig.Namespace),
		)

		//verify old workloads and delete
		common_tests.Outerloop_scanning_supplychain_verify(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		common_tests.Outerloop_scanning_supplychain_cleanup(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		t.Log("************** Ending outerloop test 2 **************")

		//new workload tests
		t.Log("************** Starting outerloop test 3 **************")
		common_tests.Outerloop_scanning_supplychain_test(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.UpgradeTapVersion)

		//upgrading tap in view cluster
		t.Log("************** Updating tap in view cluster **************")
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.ViewClusterContext),
			common_features.UpdateTapVersion(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Namespace, suiteConfig.Multicluster.ViewWithMetadataStoreTapValuesFile, upgradeMetadata.UpgradeTapVersion, suiteConfig.Tap.PollTimeout),
		)

		//verify old workloads and delete
		common_tests.Outerloop_scanning_supplychain_verify(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		common_tests.Outerloop_scanning_supplychain_cleanup(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.TapVersion)
		t.Log("************** Ending outerloop test 3 **************")

		//new workload tests
		t.Log("************** Starting outerloop test 4 **************")
		common_tests.Outerloop_scanning_supplychain_test(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.UpgradeTapVersion)
		common_tests.Outerloop_scanning_supplychain_verify(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.UpgradeTapVersion)
		common_tests.Outerloop_scanning_supplychain_cleanup(t, testenv, suiteConfig, outerloopConfig, upgradeMetadata.UpgradeTapVersion)
		t.Log("************** Ending outerloop test 4 **************")

		// cleanup tap repo and package
		testenv.Test(t,
			common_features.ChangeContext(t, suiteConfig.Multicluster.ViewClusterContext),
			common_features.DeletePackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.Namespace),
			common_features.DeletePackageRepository(t, suiteConfig.PackageRepository.Name, suiteConfig.Tap.Namespace),

			common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
			common_features.DeletePackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.Namespace),
			common_features.DeleteNamespace(t, outerloopConfig.MetadataStore.Namespace, suiteConfig.Multicluster.BuildClusterContext),
			common_features.DeletePackageRepository(t, suiteConfig.PackageRepository.Name, suiteConfig.Tap.Namespace),

			common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
			common_features.DeletePackage(t, suiteConfig.Tap.Name, suiteConfig.Tap.Namespace),
			common_features.DeletePackageRepository(t, suiteConfig.PackageRepository.Name, suiteConfig.Tap.Namespace),
		)
		t.Log("************** TestCase END: TestTapUpgrade **************")
	}
}
