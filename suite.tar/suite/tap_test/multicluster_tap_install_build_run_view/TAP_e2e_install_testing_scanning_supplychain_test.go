//go:build multicluster_tap_install_build_testing_scanning

package multicluster_tap_install_build_run_view

import (
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"testing"
)

func TestMulticlusterTAPInstallTestingScanningSupplyChain(t *testing.T) {
	t.Log("************** TestCase START: TestMulticlusterTAPInstallTestingScanningSupplyChain **************")
	testenv.Test(t,
		common_features.DeleteNamespaceIfExists(t, "metadata-store-secrets", suiteConfig.Multicluster.BuildClusterContext),
		common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
		common_features.UpdateMetadataStoreScanning(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Version, "build", "testing_scanning", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout, outerloopConfig.MetadataStore.Domain, suiteConfig.Multicluster.ViewClusterContext, suiteConfig.Multicluster.BuildClusterContext, outerloopConfig.MetadataStore.Namespace),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.SpringPetclinicPipeline.YamlFile, outerloopConfig.Namespace),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.ScanPolicy.YamlFile, outerloopConfig.Namespace),
		common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.Mysql.YamlFile, outerloopConfig.Namespace),
	)
	t.Log("************** TestCase END: TestMulticlusterTAPInstallTestingScanningSupplyChain **************")
}
