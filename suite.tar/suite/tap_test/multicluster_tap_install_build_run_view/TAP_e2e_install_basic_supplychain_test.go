//go:build multicluster_tap_install_build_basic

package multicluster_tap_install_build_run_view

import (
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"testing"
)

func TestMulticlusterTAPInstallBasicSupplyChain(t *testing.T) {
	t.Log("************** TestCase START: TestMulticlusterTAPInstallBasicSupplyChain **************")
	testenv.Test(t,
		common_features.ChangeContext(t, suiteConfig.Multicluster.BuildClusterContext),
		common_features.UpdateTapProfileSupplyChain(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Version, "build", "basic", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout),
		common_features.ChangeContext(t, suiteConfig.Multicluster.RunClusterContext),
		common_features.ApplyKubectlConfigurationFile(t, outerloopConfig.Mysql.YamlFile, outerloopConfig.Namespace),
	)
	t.Log("************** TestCase END: TestMulticlusterTAPInstallBasicSupplyChain **************")
}
