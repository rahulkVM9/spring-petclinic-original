//go:build all || innerloop || innerloop_subpath

package e2e_test

import (
	"fmt"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"strings"
	"testing"
)

func TestInnerloopBasicSupplychainWithSubPath(t *testing.T) {
	t.Log("************** TestCase START: TestInnerloopBasicSupplychainWithSubPath **************")

	wl1Url := strings.Replace(innerloopConfig.SubpathtesterRepo.URL, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service1, -1)
	wl1Originalstring := strings.Replace(innerloopConfig.SubpathtesterRepo.OriginalString, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service1, -1)
	wl1Newstring := strings.Replace(innerloopConfig.SubpathtesterRepo.NewString, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service1, -1)

	wl2Url := strings.Replace(innerloopConfig.SubpathtesterRepo.URL, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service2, -1)
	wl2Originalstring := strings.Replace(innerloopConfig.SubpathtesterRepo.OriginalString, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service2, -1)
	wl2Newstring := strings.Replace(innerloopConfig.SubpathtesterRepo.NewString, "<SERVICE-NAME>", innerloopConfig.SubpathtesterRepo.Service2, -1)

	repoPath := fmt.Sprintf("../../../suite/%s", innerloopConfig.SubpathtesterRepo.Name)
	testenv.Test(t,
		common_features.UpdateTapProfileSupplyChain(t, suiteConfig.Tap.Name, suiteConfig.Tap.PackageName, suiteConfig.Tap.Version, "light", "basic", suiteConfig.Tap.Namespace, suiteConfig.Tap.PollTimeout),
		common_features.GitClone(t, suiteConfig.GitCredentials.Username, suiteConfig.GitCredentials.Email, innerloopConfig.SubpathtesterRepo.Gitrepository),

		common_features.TanzuCreateWorkloadWithSubPath(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.SourceImage1, repoPath, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.TanzuCreateWorkloadWithSubPath(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.SourceImage2, repoPath, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyTanzuJavaWebAppBuildStatus(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.BuildNameSuffix, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuJavaWebAppBuildStatus(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.BuildNameSuffix, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyImagesKpacStatus(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyImagesKpacStatus(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyTanzuJavaWebAppImageRepositoryDelivery(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.ImageDeliverySuffix, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuJavaWebAppImageRepositoryDelivery(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.ImageDeliverySuffix, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyTanzuJavaWebAppRevisionStatus(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuJavaWebAppKsvcStatus(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyTanzuJavaWebAppRevisionStatus(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuJavaWebAppKsvcStatus(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyTanzuWorkloadStatus(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuWorkloadStatus(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyWorkloadResponse(t, wl1Url, wl1Originalstring, ""),
		common_features.VerifyWorkloadResponse(t, wl2Url, wl2Originalstring, ""),

		common_features.UpdateStringInFile(t, wl1Originalstring, wl1Newstring, innerloopConfig.SubpathtesterRepo.ApplicationFilePath1),
		common_features.UpdateStringInFile(t, wl2Originalstring, wl2Newstring, innerloopConfig.SubpathtesterRepo.ApplicationFilePath2),

		common_features.TanzuUpdateWorkloadWithSubPath(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.SourceImage1, repoPath, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.TanzuUpdateWorkloadWithSubPath(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.SourceImage2, repoPath, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.VerifyWorkloadResponse(t, wl1Url, wl1Newstring, ""),
		common_features.VerifyWorkloadResponse(t, wl2Url, wl2Newstring, ""),

		common_features.VerifyTanzuJavaWebAppDeliverable(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.VerifyTanzuJavaWebAppDeliverable(t, innerloopConfig.SubpathtesterRepo.Service2, innerloopConfig.SubpathtesterRepo.Namespace),

		common_features.TanzuDeleteWorkload(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
		common_features.TanzuDeleteWorkload(t, innerloopConfig.SubpathtesterRepo.Service1, innerloopConfig.SubpathtesterRepo.Namespace),
	)
	t.Log("************** TestCase END: TestInnerloopBasicSupplychainWithSubPath **************")
}
