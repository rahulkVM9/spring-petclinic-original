package models

import (
	"log"
	"os"
	"path/filepath"

	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils"
	"gopkg.in/yaml.v2"
)

type InnerloopConfig struct {
	SubpathtesterRepo struct {
		Name                 string `yaml:"name"`
		Service1             string `yaml:"service1"`
		Service2             string `yaml:"service2"`
		Namespace            string `yaml:"namespace"`
		URL                  string `yaml:"url"`
		Gitrepository        string `yaml:"gitrepository"`
		ApplicationFilePath1 string `yaml:"application_file_path1"`
		ApplicationFilePath2 string `yaml:"application_file_path2"`
		NewString            string `yaml:"new_string"`
		OriginalString       string `yaml:"original_string"`
		SourceImage1         string `yaml:"source_image1"`
		SourceImage2         string `yaml:"source_image2"`
		BuildNameSuffix      string `yaml:"build_name_suffix"`
		ImageDeliverySuffix  string `yaml:"image_delivery_suffix"`
	} `yaml:"subpathtester_repo"`
	Workload struct {
		Name                string `yaml:"name"`
		Namespace           string `yaml:"namespace"`
		URL                 string `yaml:"url"`
		Gitrepository       string `yaml:"gitrepository"`
		YamlFile            string `yaml:"yaml_file"`
		ApplicationFilePath string `yaml:"application_file_path"`
		NewString           string `yaml:"new_string"`
		OriginalString      string `yaml:"original_string"`
		BuildNameSuffix     string `yaml:"build_name_suffix"`
		ImageDeliverySuffix string `yaml:"image_delivery_suffix"`
	} `yaml:"workload"`
}

var innerloopResourcesDir = filepath.Join(utils.GetFileDir(), "../../resources/innerloop")

func GetInnerloopConfig() (InnerloopConfig, error) {
	log.Printf("getting innerloop config")

	InnerloopConfig := InnerloopConfig{}
	file := filepath.Join(innerloopResourcesDir, "innerloop-config.yaml")

	// read file
	InnerloopConfigBytes, err := os.ReadFile(file)
	if err != nil {
		log.Printf("error while reading innerloop config file %s", file)
		log.Printf("error: %s", err)
		return InnerloopConfig, err
	} else {
		log.Printf("read innerloop config file %s", file)
	}

	// unmarshall
	err = yaml.Unmarshal(InnerloopConfigBytes, &InnerloopConfig)
	if err != nil {
		log.Printf("error while unmarshalling innerloop config file %s", file)
		log.Printf("error: %s", err)
		return InnerloopConfig, err
	} else {
		log.Printf("unmarshalled file %s", file)
	}

	// update innerloop config for full file paths
	// InnerloopConfig.Mysql.YamlFile = filepath.Join(innerloopResourcesDir, InnerloopConfig.Mysql.YamlFile)

	return InnerloopConfig, nil
}
