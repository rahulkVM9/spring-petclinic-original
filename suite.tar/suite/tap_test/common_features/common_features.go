package common_features

import (
	"context"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	exec2 "os/exec"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"time"

	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/docker"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/git"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/github"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/imgpkg"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubectl/kubectlCmds"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubectl/kubectl_helpers"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubectl/kubectl_libs"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/kubernetes/client"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/misc"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/tanzu/tanzuCmds"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/tanzu/tanzu_helpers"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/tanzu/tanzu_libs"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils/linux_util"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/models"
	_ "k8s.io/client-go/plugin/pkg/client/auth/gcp"
	"sigs.k8s.io/e2e-framework/pkg/envconf"
	"sigs.k8s.io/e2e-framework/pkg/features"
)

var tiltprocCmdKey = "tiltprocCmd"
var rootDir = filepath.Join(utils.GetFileDir(), "../../")
var suiteResourcesDir = filepath.Join(utils.GetFileDir(), "../../resources/suite")
var outerloopResourcesDir = filepath.Join(utils.GetFileDir(), "../../resources/outerloop")
var buildName = ""
var ksvcLatestReady = ""
var revisionName = ""
var sourceRepo = ""
var service_ref = ""
var db_ref = ""
var serviceTypeName = "rabbitmq"
var serviceInstanceName = "rmq-1"
var listofServiceTypes = ""

func compile(filepath string) {
	app := "./mvnw"
	arg0 := "compile"
	cmd := exec2.Command(app, arg0)
	cmd.Dir = filepath
	stdout, err := cmd.Output()
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	fmt.Println(string(stdout))
}

func GetMavenBuild(path string) (string, error) {
	mvnCmd := fmt.Sprintf("cd %s && ./mvnw -Dmaven.test.skip=true -Dcheckstyle.skip clean package", path)
	_, err := linux_util.ExecuteCmdInBashMode(mvnCmd)
	jarPathCmd := fmt.Sprintf("cd %s && ls target | grep -i .jar | grep -v original", path)
	jarfileName, err := linux_util.ExecuteCmdInBashMode(jarPathCmd)
	if jarfileName == "" {
		log.Printf("Jar file is not generated in %s", filepath.Join(path, "target"))
		log.Printf("Excepted jar : %s", jarfileName)
		return "", err
	}
	jarPath := filepath.Join(path, "target", jarfileName)
	return jarPath, err
}

func GetMavenInstall(path string, groupId string, artifactId string, version string, gitRepo string) (string, error) {
	jarDir := filepath.Join(rootDir, gitRepo)
	jarPathCmd := fmt.Sprintf("cd %s && ls target | grep -i .jar | grep -v original", jarDir)
	jarfileName, err := linux_util.ExecuteCmdInBashMode(jarPathCmd)
	if jarfileName == "" {
		log.Printf("Jar is not present at %s ", jarPathCmd)
		return "", err
	}
	jarPath := filepath.Join(jarDir, "target", jarfileName)
	mavenInstallFromJarCmd := fmt.Sprintf("cd %s && ./mvnw install:install-file -DgroupId=%s -DartifactId=%s -Dversion=%s -Dfile=%s -Dpackaging=jar -DgeneratePom=true -DlocalRepositoryPath=. -DcreateChecksum=true", path, groupId, artifactId, version, jarPath)
	output, err := linux_util.ExecuteCmdInBashMode(mavenInstallFromJarCmd)
	return output, err
}

func UpdatePackageRepository(t *testing.T, name string, registry string, namespace string) features.Feature {
	return features.New("updating package repository").
		Assess(fmt.Sprintf("updating-packaging-repository-%s", name), func(ctx context.Context, t *testing.T, c *envconf.Config) context.Context {
			val, present := os.LookupEnv("TKGM")
			if present && val == "true" {
				log.Printf("updating pacakage repository %s", name)
				tanzu_libs.TanzuUpdatePackageRepository(name, registry, namespace)

			} else {
				log.Printf("adding package repository %s", name)
				// envfuncs.InstallClusterEssentialsLatest()
				err := tanzuCmds.TanzuAddPackageRepository(name, registry, namespace)
				if err == nil {
					t.Logf("Installed repository : %s, image: %s successfully", name, registry)
				} else {
					t.Error(fmt.Errorf("install FAILED for repository : %s, image: %s", name, registry))
					t.Fail()
				}
			}
			updated := tanzu_helpers.CheckIfPackageRepositoryReconciled(name, namespace, 5, 30)
			if updated {
				t.Logf("Updated repository : %s, image: %s successfully", name, registry)
			} else {
				t.Error(fmt.Errorf("update FAILED for repository : %s, image: %s", name, registry))
				t.Fail()
			}
			return ctx
		}).Feature()
}

func AddPackageRepository(t *testing.T, name string, registry string, namespace string) features.Feature {
	return features.New("adding package repository").
		Assess(fmt.Sprintf("adding-packaging-repository-%s", name), func(ctx context.Context, t *testing.T, c *envconf.Config) context.Context {
			log.Printf("adding package repository %s (%s) in namespace %s", name, registry, namespace)
			// add repo
			err := tanzuCmds.TanzuAddPackageRepository(name, registry, namespace)
			if err == nil {
				t.Logf("Installed repository : %s, image: %s successfully", name, registry)
			} else {
				t.Error(fmt.Errorf("install FAILED for repository : %s, image: %s", name, registry))
				t.Fail()
			}
			updated := tanzu_helpers.CheckIfPackageRepositoryReconciled(name, namespace, 5, 30)
			if updated {
				t.Logf("Updated repository : %s, image: %s successfully", name, registry)
			} else {
				t.Error(fmt.Errorf("update FAILED for repository : %s, image: %s", name, registry))
				t.Fail()
			}
			return ctx
		}).Feature()
}

func DeletePackageRepository(t *testing.T, name string, namespace string) features.Feature {
	return features.New("deleting package repository").
		Assess(fmt.Sprintf("deleting-packaging-repository-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("deleting package repository %s in namespace %s", name, namespace)

			// delete repo
			err := tanzuCmds.TanzuDeletePackageRepository(name, namespace)
			if err != nil {
				t.Errorf("error while deleting package repository %s in namespace %s", name, namespace)
				t.Fail()
			}
			return ctx
		}).Feature()
}

func InstallPackage(t *testing.T, name string, packageRepository string, version string, namespace string, valuesFile string, pollTimeout string) features.Feature {
	return features.New("installing package").
		Assess(fmt.Sprintf("installing-package-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("installing tap package  %s (%s)", name, packageRepository)
			err := tanzu_libs.InstallPackage(name, packageRepository, version, namespace, valuesFile, pollTimeout)
			if err != nil {
				// if error, check via kubectl, not tanzu-cli
				pass := kubectl_helpers.ValidateTAPInstallation(name, namespace, 10, 60)
				if !pass {
					kubectl_helpers.LogFailedResourcesDetails(namespace)
					log.Printf("error while installing package %s (%s)", name, packageRepository)
					return ctx
				} else {
					return ctx
				}
			}
			return ctx
		}).
		Feature()

}

func DeletePackage(t *testing.T, name string, namespace string) features.Feature {
	return features.New("deleting-package").
		Assess(fmt.Sprintf("deleting-package-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			err := tanzu_libs.DeleteInstalledPackage(name, namespace)
			if err != nil {
				t.Error(fmt.Errorf("uninstallation failed for package : %s", name))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func CheckIfPackageInstalled(name string, namespace string, recursiveCount int, secondsGap int) features.Feature {
	return features.New("checking package").
		Assess(fmt.Sprintf("checking-package-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("checking package %s installation status", name)

			for ; recursiveCount >= 0; recursiveCount-- {
				// get status
				packageInstalledStatus, err := tanzuCmds.TanzuGetPackageInstalledStatus(name, namespace)
				if err != nil {
					t.Errorf("error while getting package %s in namespace %s installation status", name, namespace)
					t.Fail()
				}

				// check
				if packageInstalledStatus == "Reconciling" || packageInstalledStatus == "" {
					log.Printf("package %s is getting installed", name)
					log.Printf("sleeping for %d seconds", secondsGap)
					time.Sleep(time.Duration(secondsGap) * time.Second)
				} else if packageInstalledStatus == "Reconcile succeeded" {
					log.Printf("package %s is installed", name)
				} else if packageInstalledStatus == "Reconcile Failed" {
					t.Errorf("package %s installation failed", name)
					t.Fail()
				} else {
					t.Errorf("package %s installation unknown", name)
					t.Fail()
				}
			}

			return ctx
		}).Feature()
}

func UpdateTapVersion(t *testing.T, name string, tapPackageName string, namespace string, valuesFile string, tapVersion string, pollTimeout string) features.Feature {
	return features.New(fmt.Sprintf("updating-tap-version-%s", tapVersion)).
		Assess(fmt.Sprintf("updating-tap-package-%s", tapVersion), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("updating tap- %s ", tapVersion)
			tanzu_libs.UpdateInstalledPackage(name, tapPackageName, tapVersion, namespace, valuesFile, pollTimeout)
			updated := tanzu_helpers.ValidateInstalledPackageVersion(name, namespace, tapVersion, 30, 60)
			if updated {
				t.Logf("Updated tap version: %s successfully", tapVersion)
			} else {
				t.Error(fmt.Errorf("update FAILED for tap version: %s", tapVersion))
				t.Fail()
			}
			availablePkgs := tanzu_libs.ListInstalledPackages(namespace)
			for _, pkg := range availablePkgs {
				installed := tanzu_helpers.ValidateInstalledPackageStatus(pkg.NAME, namespace, 15, 60)
				if installed {
					t.Logf("Installed package : %s, version: %s successfully", pkg.NAME, pkg.PACKAGE_VERSION)
				} else {
					t.Errorf("Installation FAILED for package : %s, version: %s, status: %s", pkg.NAME, pkg.PACKAGE_VERSION, pkg.STATUS)
					t.Fail()
				}
			}
			log.Printf("final packages version after tap update...")
			tanzu_libs.ListInstalledPackages(namespace)
			return ctx
		}).
		Feature()
}

func UpdateTapProfileSupplyChain(t *testing.T, name string, tapPackageName string, tapVersion string, profile string, supplyChain string, namespace string, pollTimeout string) features.Feature {
	return features.New("update-tap-profile-supplychain").
		Assess("update-package", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("updating tap package")

			var tapValuesSchema models.TapValuesSchema
			var err error
			// get schema and update values
			if profile == "" {
				tapValuesSchema, err = models.GetTapValuesSchema()
				if err != nil {
					t.Error("error while getting tap values schema")
					t.FailNow()
				}
			} else {
				tapValuesSchema, err = models.GetProfileTapValuesSchema(profile)
				if err != nil {
					t.Error("error while getting tap values schema")
					t.FailNow()
				}
				tapValuesSchema.Profile = profile
			}
			t.Log(tapValuesSchema)
			if supplyChain != "" {
				tapValuesSchema.SupplyChain = supplyChain
			}

			err2 := tanzu_helpers.UpdateTapValues(tapValuesSchema, name, tapPackageName, tapVersion, namespace)
			if err2 != nil {
				t.Error("error while updating tap values")
				t.FailNow()
			}
			return ctx
		}).
		Feature()
}

func UpdateTapProfileGitopsSsh(t *testing.T, name string, tapPackageName string, tapVersion string, profile string, supplyChain string, gitopsSecret string, namespace string, pollTimeout string) features.Feature {
	return features.New("update-tap-profile-gitops-ssh").
		Assess("update-package", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("updating tap package")

			var tapValuesSchema models.TapValuesSchema
			var err error
			// get schema and update values
			if profile == "" {
				tapValuesSchema, err = models.GetTapValuesSchema()
				if err != nil {
					t.Error("error while getting tap values schema")
					t.FailNow()
				}
			} else {
				tapValuesSchema, err = models.GetProfileTapValuesSchema(profile)
				if err != nil {
					t.Error("error while getting tap values schema")
					t.FailNow()
				}
				tapValuesSchema.Profile = profile
			}
			t.Log(tapValuesSchema)
			if supplyChain != "" {
				tapValuesSchema.SupplyChain = supplyChain
			}

			tapValuesSchema.OotbSupplyChainBasic.Gitops.SSHSecret = gitopsSecret
			err2 := tanzu_helpers.UpdateTapValues(tapValuesSchema, name, tapPackageName, tapVersion, namespace)
			if err2 != nil {
				t.Error("error while updating tap values")
				t.FailNow()
			}
			return ctx
		}).
		Feature()
}

func UpdateMetadataStoreScanning(t *testing.T, name string, tapPackageName string, tapVersion string, profile string, supplyChain string, namespace string, pollTimeout string, metadataDomain string, viewContext string, buildContext string, metadataStoreSecretsNamespace string) features.Feature {
	return features.New("update-tap-profile-metadata-store-scanning").
		Assess("update-package", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("updating tap package")

			// changing to view cluster
			_, err := kubectl_libs.UseContext(viewContext)
			if err != nil {
				t.Errorf("error while changing context to %s", viewContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", viewContext)
			}

			//getting ingresss ca cert and adding as tls secret
			CA_cert := kubectl_libs.GetSecret("ingress-cert", "metadata-store").Data.CaCrt
			storeCaCertPath := filepath.Join(outerloopResourcesDir, "store-ca.yaml")
			utils.ReplaceStringInFile(storeCaCertPath, "<CA_CERT>", CA_cert)

			//getting store-auth-token
			secrets := kubectl_libs.GetSecrets("", "metadata-store")
			var secretToken string
			for _, secret := range secrets {
				if secret.Metadata.Annotations.KubernetesIoServiceAccountName == "metadata-store-read-write-client" {
					log.Printf("found matching secret %s", secret.Metadata.Name)
					secretToken = secret.Data.Token
				}
			}
			authToken, err := base64.StdEncoding.DecodeString(secretToken)
			if err != nil {
				t.Error("error while decoding token")
				t.FailNow()
			}

			// changing to build cluster
			_, err = kubectl_libs.UseContext(buildContext)
			if err != nil {
				t.Errorf("error while changing context to %s", buildContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", buildContext)
			}

			err = kubectl_libs.KubectlCreateNamespaceIfNotExists(metadataStoreSecretsNamespace)
			if err != nil {
				t.Errorf("error while creating namespace %s", metadataStoreSecretsNamespace)
				t.FailNow()
			}
			err = kubectl_libs.KubectlApplyConfiguration(storeCaCertPath, "")
			if err != nil {
				t.Log("error while creating secret store-ca-cert secret")
			}
			literal_source := fmt.Sprintf("auth_token=%s", string(authToken))
			err = kubectl_libs.KubectlCreateSecretIfNotExists(metadataStoreSecretsNamespace, "store-auth-token", literal_source, "generic")
			if err != nil {
				t.Error("error while creating secret store-auth-token")
				t.FailNow()
			}

			secretsExportsFile := ""

			if strings.Split(tapVersion, ".")[1] <= "1" {
				secretsExportsFile = "store-secrets-exports-imports-1.1.x.yaml"
			} else {
				secretsExportsFile = "store-secrets-exports-imports.yaml"
			}

			//creating secret export and secret import

			secretExportImportManifestPath := filepath.Join(outerloopResourcesDir, secretsExportsFile)
			kubectl_libs.KubectlApplyConfiguration(secretExportImportManifestPath, "")

			//update scanning in tap
			var tapValuesSchema models.TapValuesSchema
			tapValuesSchema, err = models.GetProfileTapValuesSchema("build")
			if err != nil {
				t.Error("error while getting tap values schema")
				t.FailNow()
			}
			t.Log(tapValuesSchema)

			// set url
			if !strings.HasPrefix(metadataDomain, "https://") {
				metadataDomain = "https://" + metadataDomain
			}

			tapValuesSchema.Profile = profile
			tapValuesSchema.SupplyChain = supplyChain

			if strings.Split(tapVersion, ".")[1] <= "1" {
				t.Log("tap version is less than 1.2.x, hence older schema for scanning")
				tapValuesSchema.Scanning.MetadataStore.URL = metadataDomain
				tapValuesSchema.Scanning.MetadataStore.CaSecret.Name = "store-ca-cert"
				tapValuesSchema.Scanning.MetadataStore.CaSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Scanning.MetadataStore.AuthSecret.Name = "store-auth-token"
				tapValuesSchema.Scanning.MetadataStore.AuthSecret.ImportFromNamespace = metadataStoreSecretsNamespace

			} else {
				t.Log("tap version is equal to or more than 1.2, hence newer schema for scanning")
				tapValuesSchema.Grype.MetadataStore.URL = metadataDomain
				tapValuesSchema.Grype.MetadataStore.CaSecret.Name = "store-ca-cert"
				tapValuesSchema.Grype.MetadataStore.CaSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Grype.MetadataStore.AuthSecret.Name = "store-auth-token"
				tapValuesSchema.Grype.MetadataStore.AuthSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Scanning.MetadataStore.URL = ""
			}

			err = tanzu_helpers.UpdateTapValues(tapValuesSchema, name, tapPackageName, tapVersion, namespace)
			if err != nil {
				t.Error("error while updating tap values")
			}
			updated := tanzu_helpers.ValidateInstalledPackageVersion(name, namespace, tapVersion, 30, 60)
			if updated {
				t.Logf("Updated tap version: %s successfully", tapVersion)
			} else {
				t.Error(fmt.Errorf("update FAILED for tap version: %s", tapVersion))
				t.Fail()
			}
			log.Printf("final packages version after tap update...")
			tanzu_libs.ListInstalledPackages(namespace)

			return ctx
		}).
		Feature()
}

func UpdateMetadataStoreAndInstallSnykScanning(t *testing.T, name string, tapPackageName string, tapVersion string, profile string, supplyChain string, namespace string, pollTimeout string, metadataDomain string, viewContext string, buildContext string, metadataStoreSecretsNamespace string, valuesFile string) features.Feature {
	return features.New("update-tap-profile-metadata-store-with-snyk-scanning").
		Assess("update-package", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("updating tap package")

			// changing to view cluster
			_, err := kubectl_libs.UseContext(viewContext)
			if err != nil {
				t.Errorf("error while changing context to %s", viewContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", viewContext)
			}

			//getting ingresss ca cert and adding as tls secret
			CA_cert := kubectl_libs.GetSecret("ingress-cert", "metadata-store").Data.CaCrt
			storeCaCertPath := filepath.Join(outerloopResourcesDir, "store-ca.yaml")
			utils.ReplaceStringInFile(storeCaCertPath, "<CA_CERT>", CA_cert)

			//getting store-auth-token
			secrets := kubectl_libs.GetSecrets("", "metadata-store")
			var secretToken string
			for _, secret := range secrets {
				if secret.Metadata.Annotations.KubernetesIoServiceAccountName == "metadata-store-read-write-client" {
					log.Printf("found matching secret %s", secret.Metadata.Name)
					secretToken = secret.Data.Token
				}
			}
			authToken, err := base64.StdEncoding.DecodeString(secretToken)
			if err != nil {
				t.Error("error while decoding token")
				t.FailNow()
			}

			// changing to build cluster
			_, err = kubectl_libs.UseContext(buildContext)
			if err != nil {
				t.Errorf("error while changing context to %s", buildContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", buildContext)
			}

			err = kubectl_libs.KubectlCreateNamespaceIfNotExists(metadataStoreSecretsNamespace)
			if err != nil {
				t.Errorf("error while creating namespace %s", metadataStoreSecretsNamespace)
				t.FailNow()
			}
			err = kubectl_libs.KubectlApplyConfiguration(storeCaCertPath, "")
			if err != nil {
				t.Log("error while creating secret store-ca-cert secret")
			}
			literal_source := fmt.Sprintf("auth_token=%s", string(authToken))
			err = kubectl_libs.KubectlCreateSecretIfNotExists(metadataStoreSecretsNamespace, "store-auth-token", literal_source, "generic")
			if err != nil {
				t.Error("error while creating secret store-auth-token")
				t.FailNow()
			}

			secretsExportsFile := ""

			if strings.Split(tapVersion, ".")[1] <= "1" {
				secretsExportsFile = "store-secrets-exports-imports-1.1.x.yaml"
			} else {
				secretsExportsFile = "store-secrets-exports-imports.yaml"
			}

			//creating secret export and secret import

			secretExportImportManifestPath := filepath.Join(outerloopResourcesDir, secretsExportsFile)
			kubectl_libs.KubectlApplyConfiguration(secretExportImportManifestPath, "")

			// install snyk scanning
			packageName := "snyk.scanning.apps.tanzu.vmware.com"
			t.Logf("Installing package: %s", packageName)
			availablePkgs := tanzu_libs.ListAvailablePackages(packageName, namespace)
			t.Logf("package name: %s, version: %s", packageName, availablePkgs[0].VERSION)
			tanzu_libs.InstallPackage("snyk-scanner", packageName, availablePkgs[0].VERSION, namespace, valuesFile, pollTimeout)
			installed := tanzu_helpers.ValidateInstalledPackageStatus(name, namespace, 5, 30)
			if installed {
				t.Logf("Installed package : %s, version: %s successfully", name, availablePkgs[0].VERSION)
			} else {
				t.Error(fmt.Errorf("Installation FAILED for package : %s, version: %s", name, availablePkgs[0].VERSION))
				t.Fail()
			}
			//update scanning in tap
			var tapValuesSchema models.TapValuesSchema
			tapValuesSchema, err = models.GetProfileTapValuesSchema("build")
			if err != nil {
				t.Error("error while getting tap values schema")
				t.FailNow()
			}
			t.Log(tapValuesSchema)

			// set url
			if !strings.HasPrefix(metadataDomain, "https://") {
				metadataDomain = "https://" + metadataDomain
			}

			tapValuesSchema.Profile = profile
			tapValuesSchema.SupplyChain = supplyChain

			if strings.Split(tapVersion, ".")[1] <= "1" {
				t.Log("tap version is less than 1.2.x, hence older schema for scanning")
				tapValuesSchema.Scanning.MetadataStore.URL = metadataDomain
				tapValuesSchema.Scanning.MetadataStore.CaSecret.Name = "store-ca-cert"
				tapValuesSchema.Scanning.MetadataStore.CaSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Scanning.MetadataStore.AuthSecret.Name = "store-auth-token"
				tapValuesSchema.Scanning.MetadataStore.AuthSecret.ImportFromNamespace = metadataStoreSecretsNamespace

			} else {
				t.Log("tap version is equal to or more than 1.2, hence newer schema for scanning")
				tapValuesSchema.OotbSupplyChainTestingScanning.Scanning.Image.Template = "snyk-private-image-scan-template"
				tapValuesSchema.OotbSupplyChainTestingScanning.Scanning.Image.Policy = "scan-policy"
				tapValuesSchema.Grype.MetadataStore.URL = metadataDomain
				tapValuesSchema.Grype.MetadataStore.CaSecret.Name = "store-ca-cert"
				tapValuesSchema.Grype.MetadataStore.CaSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Grype.MetadataStore.AuthSecret.Name = "store-auth-token"
				tapValuesSchema.Grype.MetadataStore.AuthSecret.ImportFromNamespace = metadataStoreSecretsNamespace
				tapValuesSchema.Scanning.MetadataStore.URL = ""
			}

			err = tanzu_helpers.UpdateTapValues(tapValuesSchema, name, tapPackageName, tapVersion, namespace)
			if err != nil {
				t.Error("error while updating tap values")
			}
			updated := tanzu_helpers.ValidateInstalledPackageVersion(name, namespace, tapVersion, 30, 60)
			if updated {
				t.Logf("Updated tap version: %s successfully", tapVersion)
			} else {
				t.Error(fmt.Errorf("update FAILED for tap version: %s", tapVersion))
				t.Fail()
			}
			log.Printf("final packages version after tap update...")
			tanzu_libs.ListInstalledPackages(namespace)

			return ctx
		}).
		Feature()
}

func TanzuDeployWorkload(t *testing.T, workloadYamlFile string, namespace string) features.Feature {
	return features.New("deploy-tanzu-workload-via-yaml").
		Assess(fmt.Sprintf("deploy-workload-from-%s", workloadYamlFile), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying workload yaml %s", workloadYamlFile)
			//workloadFilePath := filepath.Join(rootDir, workloadYamlFile)
			// deploy app
			err := tanzu_libs.TanzuApplyWorkload(namespace, workloadYamlFile)
			if err != nil {
				t.Errorf("error while deploying workload yaml %s", workloadYamlFile)
				t.FailNow()
			} else {
				t.Logf("deployed workload yaml %s", workloadYamlFile)
			}

			return ctx
		}).
		Feature()
}

func TanzuDeleteWorkload(t *testing.T, name string, namespace string) features.Feature {
	return features.New("delete-tanzu-workload").
		Assess(fmt.Sprintf("delete-workload-from-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deleting workload %s", name)
			// deploy app
			err := tanzu_libs.DeleteWorkload(name, namespace)
			if err != nil {
				t.Errorf("error while deleting workload %s", name)
				t.FailNow()
			} else {
				t.Logf("deleting workload %s", name)
			}
			t.Logf("Waiting for 2 mins after workload deletion to avoid ns getting stuck at deletion")
			time.Sleep(time.Duration(120) * time.Second)
			return ctx
		}).
		Feature()
}

func GitClone(t *testing.T, gitUsername string, gitEmail string, gitRepository string) features.Feature {
	return features.New("git-update").
		Assess("git-config", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("setting git config")

			// set git config
			err := git.GitConfig(gitUsername, gitEmail)
			if err != nil {
				t.Error("error while setting git config")
				t.FailNow()
			} else {
				t.Log("set git config")
			}

			return ctx
		}).
		Assess("git-clone", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("cloning git repo")

			// clone
			err := git.GitClone(rootDir, gitRepository)
			if err != nil {
				t.Error("error while cloning git repo")
				t.FailNow()
			} else {
				t.Log("cloned git repo")
			}
			return ctx

		}).
		Feature()
}

func ReplaceStringInFile(t *testing.T, originalString string, newString string, filePath string, workload string) features.Feature {
	return features.New("replace-string-in-file").
		Assess("replace-tanzu-to-tap ", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			oldString := originalString
			newString := newString
			filePath := filepath.Join(rootDir, filePath)
			t.Logf("Replace from string %s to string %s in file %s", oldString, newString, filePath)
			err := utils.ReplaceStringInFile(filePath, oldString, newString)
			t.Logf("Compiling and building app %s", workload)
			compile(filepath.Join(rootDir, workload))
			if err != nil {
				t.Error(fmt.Errorf("error while replacing string in file %s : %w", filePath, err))
				t.FailNow()
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuWorkloadStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("verify-%sworkload-status", name)).
		Assess(fmt.Sprintf("verify-tanzu-%s-ready", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying tanzu %s ready status", name)

			// check
			// status := kubectl_helpers.ValidateWorkloadStatus(name, namespace, 10, 10)
			status := kubectl_helpers.ValidateWorkloadStatus(name, namespace, 15, 60)
			t.Logf("workload %s validation status : %v", name, status)
			if !status {
				// tanzu apps workload get
				tanzu_libs.GetWorkloadDetails(name, namespace)
				t.Error(fmt.Errorf("workload %s is not ready", name))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func CreateGithubRepo(t *testing.T, name string, repoTemplate string, accessToken string) features.Feature {
	return features.New("create-github-repo").
		Assess("create-github-repo", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("creating github repo")

			// create repo
			err := github.CreateGithubRepo(name, repoTemplate, accessToken)
			if err != nil {
				t.Error("error while creating repo ")
				t.FailNow()
			} else {
				t.Log("created repo")
			}
			return ctx
		}).
		Feature()
}

func DeleteGithubRepo(t *testing.T, name string, accessToken string) features.Feature {
	return features.New("delete-github-repo").
		Assess("delete-github-repo", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("deleting github repo")

			// create repo
			err := github.DeleteGithubRepo(name, accessToken)
			if err != nil {
				t.Error("error while deleting repo ")
				t.FailNow()
			} else {
				t.Log("deleted repo")
			}
			return ctx
		}).
		Feature()
}

func ApplyKubectlConfigurationFile(t *testing.T, configurationFile string, namespace string) features.Feature {
	return features.New("deploy-yaml").
		Assess(fmt.Sprintf("deploy-%s", configurationFile), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying %s", configurationFile)

			// deploy app
			err := kubectlCmds.KubectlApplyConfiguration(configurationFile, namespace)
			if err != nil {
				t.Errorf("error while deploying %s", configurationFile)
				t.FailNow()
			} else {
				t.Logf("deployed %s", configurationFile)
			}

			return ctx
		}).
		Feature()
}

func DeleteKubectlConfigurationFile(t *testing.T, configurationFile string, namespace string) features.Feature {
	return features.New("delete-yaml").
		Assess(fmt.Sprintf("delete-%s", configurationFile), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deleting %s", configurationFile)

			// deploy app
			err := kubectlCmds.KubectlDeleteConfiguration(configurationFile, namespace)
			if err != nil {
				t.Errorf("error while deleting %s", configurationFile)
				t.FailNow()
			} else {
				t.Logf("deleted %s", configurationFile)
			}

			return ctx
		}).
		Feature()
}

func InstallAndDeployRmqOperator(t *testing.T, name string, configurationFile string) features.Feature {
	return features.New("install-and-deploy-rmq-yaml").
		Assess(fmt.Sprintf("deploy-%s", configurationFile), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying %s", configurationFile)

			// deploy app
			err := kubectl_libs.DeployApp(name, configurationFile)
			if err != nil {
				t.Errorf("error while deploying RabbitMQ operator app")
				t.FailNow()
			} else {
				t.Logf("deployed RabbitMQ operator app %s", configurationFile)
			}

			return ctx
		}).
		Feature()
}

func DeleteApp(t *testing.T, name string) features.Feature {
	return features.New("delete-app").
		Assess(fmt.Sprintf("delete-app-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deleting %s", name)

			// deploy app
			err := kubectl_libs.DeleteApp(name)
			if err != nil {
				t.Errorf("error while deleting app")
				t.FailNow()
			} else {
				t.Logf("deleted app  %s", name)
			}

			return ctx
		}).
		Feature()
}

func VerifyWorkloadResponse(t *testing.T, workloadUrl string, verificationString string, relativePath string) features.Feature {
	return features.New("verify-workload-response").
		Assess("get-externalip-and-check-webpage-for-string", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("getting external ip and checking for string")

			// get external IP
			url := kubectl_helpers.GetServiceExternalIP("envoy", "tanzu-system-ingress", 2, 30)
			if relativePath != "" {
				url = fmt.Sprintf("%s/%s", url, relativePath)
			}
			// set url
			if !strings.HasPrefix(url, "http://") {
				url = "http://" + url
			}

			webpageContainsString, _ := misc.VerifyWebpageContainsString(workloadUrl, url, verificationString, 20, 10, 30)
			if !webpageContainsString {
				t.Error("webpage does not contains string")
				t.Fail() // DON'T DO t.FailNow() AS WE WANT TO CLEAN UP REGARDLESS OF THE STATE OF THE TEST
			} else {
				t.Log("webpage contains string")
			}

			return ctx
		}).
		Feature()
}

func VerifyGitRepoStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("verify-%s-gitrepo-status", name)).
		Assess("verify-gitrepo-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying gitrepo ready status")

			// check
			gitrepoReady := kubectl_helpers.VerifyGitRepoStatus(name, namespace, 5, 30)
			if !gitrepoReady {
				t.Error("gitrepo not ready")
				t.FailNow()
			} else {
				t.Log("gitrepo ready")
			}
			return ctx
		}).
		Feature()
}

func VerifyBuildStatus(t *testing.T, name string, buildNameSuffix string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("verify-%s-build-status", name)).
		Assess("verify-build-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify build status")
			buildName = fmt.Sprintf("%s%s", name, buildNameSuffix)
			status := kubectl_helpers.VerifyBuildStatus(buildName, namespace, 30, 60)
			t.Logf("Build status is : %t", status)
			if !status {
				t.Error(fmt.Errorf("build is not ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyBuildStatusAfterUpdate(t *testing.T, name string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("verify-%s-build-status", name)).
		Assess("verify-build-succeeded", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying build succeeded status")

			buildSucceeded := kubectl_helpers.VerifyNewerBuildStatus(buildName, namespace, 15, 60)
			if !buildSucceeded {
				t.Error("build not succeeded")
				t.FailNow()
			} else {
				t.Log("build succeeded")
			}
			buildName = kubectl_helpers.GetLatestBuildName(namespace)
			return ctx
		}).
		Feature()
}

func VerifyPodIntentStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-podintents-labels-conventions").
		Assess("verify-podintent-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying podintent ready status")

			// check
			if !kubectl_helpers.VerifyPodIntentStatus(name, namespace, 5, 30) {
				t.Error("podintent not ready")
				t.FailNow()
			} else {
				t.Log("podintent ready")
			}
			return ctx
		}).
		Assess("verify-podintent-alv-lables", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying appliveview labels present in podintent")

			// check
			alvLabelsPresent := kubectl_helpers.ValidateAppLiveViewLabels(name, namespace)
			if !alvLabelsPresent {
				t.Error("appliveview lables absent in podintent")
				t.FailNow()
			} else {
				t.Log("appliveview labels present in podintent")
			}
			return ctx
		}).
		Assess("verify-podintent-springbootconventions-lables", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying springbootconventions labels present in podintent")

			// check
			springbootconventionsLabelsPresent := kubectl_helpers.ValidateSpringBootLabels(name, namespace)
			if !springbootconventionsLabelsPresent {
				t.Error("springbootconventions lables absent in podintent")
				t.FailNow()
			} else {
				t.Log("springbootconventions labels present in podintent")
			}
			return ctx
		}).
		Assess("verify-podintent-alv-conventions", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying appliveview conventions present in podintent")

			// check
			appliveviewConventionsPresent := kubectl_helpers.ValidateAppLiveViewConventions(name, namespace)
			if !appliveviewConventionsPresent {
				t.Error("appliveview conventions absent in podintent")
				t.FailNow()
			} else {
				t.Log("appliveview conventions present in podintent")
			}
			return ctx
		}).
		Assess("verify-podintent-springbootconventions-conventions", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying springbootconventions conventions present in podintent")

			// check
			springbootconventionsConventionsPresent := kubectl_helpers.ValidateSpringBootConventions(name, namespace)
			if !springbootconventionsConventionsPresent {
				t.Error("springbootconventions conventions absent in podintent")
				t.FailNow()
			} else {
				t.Log("springbootconventions conventions present in podintent")
			}
			return ctx
		}).
		Feature()
}

func VerifyTaskRunStatus(t *testing.T, name string, taskRunInfix string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("verify-%s-taskrun-status", name)).
		Assess("verify-taskrun-succeeded", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying taskrun succeeded status")

			taskRunPrefix := fmt.Sprintf("%s%s", name, taskRunInfix)
			taskrunSucceeded := kubectl_helpers.VerifyTaskrunStatus(taskRunPrefix, namespace, 5, 30)
			if !taskrunSucceeded {
				t.Error("taskrun not succeeded")
				t.FailNow()
			} else {
				t.Log("taskrun succeeded")
			}
			return ctx
		}).
		Feature()
}

func ImgPkgCopyToRepo(t *testing.T, sourceBundle string, targetRepo string) features.Feature {
	return features.New("imgpkg-copy").
		Assess(fmt.Sprintf("%s --> %s", sourceBundle, targetRepo), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("copying image bundles from %s to %s", sourceBundle, targetRepo)

			// deploy app
			err := imgpkg.ImgpkgCopy(sourceBundle, targetRepo)
			if err != nil {
				t.Errorf("error while copying image bundles from %s to %s", sourceBundle, targetRepo)
				t.FailNow()
			} else {
				t.Logf("copied image bundles from %s to %s", sourceBundle, targetRepo)
			}

			return ctx
		}).
		Feature()
}

func CreateSecret(t *testing.T, name string, registry string, username string, password string, passwordType string, namespace string, export bool) features.Feature {
	return features.New(fmt.Sprintf("creating secret %s", name)).
		Assess(fmt.Sprintf("creating secret %s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("creating secret %s (registry %s, username %s) in namespace %s", name, registry, username, namespace)

			// create secret
			err := tanzuCmds.TanzuCreateSecret(name, registry, username, password, passwordType, namespace, export)
			if err != nil {
				t.Errorf("error while creating secret %s", name)
				t.FailNow()
			} else {
				t.Logf("created secret %s", name)
			}

			return ctx
		}).Feature()
}

func DeleteSecret(t *testing.T, name string, namespace string) features.Feature {
	return features.New(fmt.Sprintf("deleting secret %s", name)).
		Assess(fmt.Sprintf("deleting secret %s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			log.Printf("deleting secret %s in namespace %s", name, namespace)

			// create secret
			err := tanzuCmds.TanzuDeleteSecret(name, namespace)
			if err != nil {
				t.Errorf("error while deleting secret %s", name)
				t.FailNow()
			} else {
				t.Logf("deleted secret %s", name)
			}

			return ctx
		}).Feature()
}

func DockerLogin(t *testing.T, server string, username string, password string) features.Feature {
	return features.New("Docker login server").
		Assess(fmt.Sprintf("Logging in server %s", server), func(ctx context.Context, t *testing.T, c *envconf.Config) context.Context {

			err := docker.DockerLogin(server, username, password)
			if err != nil {
				t.Errorf("error while loging in server %s", server)
				t.FailNow()
			} else {
				t.Logf("docker login success for %s", server)
			}

			return ctx
		}).Feature()
}

func ChangeContext(t *testing.T, clusterContext string) features.Feature {
	return features.New("changing cluster context").
		Assess(fmt.Sprintf("changing cluster context to %s", clusterContext), func(ctx context.Context, t *testing.T, c *envconf.Config) context.Context {

			_, err := kubectl_libs.UseContext(clusterContext)
			if err != nil {
				t.Errorf("error while changing context to %s", clusterContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", clusterContext)
			}
			return ctx
		}).Feature()
}

func VerifyTanzuJavaWebAppImageRepository(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-image-repositories").
		Assess("verify-image-repositories", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify image-repositories status")
			status := kubectl_helpers.VerifyImageRepositoryStatus(name, namespace, 10, 30)
			t.Logf("ImageRepository %s status is : %t", name, status)
			if !status {
				t.Error(fmt.Errorf("image repository %s is not ready", name))
				t.Fail()
			}
			return ctx
		}).Feature()
}

func GenerateAcceleratorProject(t *testing.T, namespace string) features.Feature {
	return features.New("generate-acc-project-and-unzip").
		Assess("generate-project", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			service, accNamespace := "acc-server", "accelerator-system"
			t.Logf("getting external ip for %s (namespace %s)", service, accNamespace)
			serviceExternalIp := kubectl_helpers.GetServiceExternalIP(service, accNamespace, 2, 30)
			// if err != nil {
			// 	t.Error(fmt.Errorf("error while getting external ip for %s (namespace %s): %w", service, accNamespace, err))
			// 	t.FailNow()
			// }
			t.Logf("external ip for %s (namespace %s): %s", "server", accNamespace, serviceExternalIp)
			t.Logf("sleeping for 1 minute before generating project")
			t.Logf("generating tanzu java web app accelerator project")
			tapValuesSchema, err := models.GetProfileTapValuesSchema("iterate")
			if err != nil {
				t.Error(fmt.Errorf("error while getting tap values schema: %w", err))
			}
			// generate project
			repositoryPrefix := tapValuesSchema.OotbSupplyChainBasic.Registry.Server + "/" + tapValuesSchema.OotbSupplyChainBasic.Registry.Repository
			err = tanzuCmds.TanzuGenerateAccelerator("tanzu-java-web-app", "tanzu-java-web-app", repositoryPrefix, serviceExternalIp, namespace, 4, 30)
			if err != nil {
				t.Error("error while generating accelerator project")
				t.FailNow()
			} else {
				t.Log("accelerator project generated")
			}

			return ctx
		}).
		Assess("unzip-project", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			project := filepath.Join(rootDir, "tanzu-java-web-app")
			zipFile := "tanzu-java-web-app" + ".zip"
			t.Logf("listing existing project files if exists")
			output, err := linux_util.ExecuteCmd(fmt.Sprintf("ls -lt %s", project))
			t.Logf("command executed: ls -lt %s. output %s", project, output)
			if err == nil {
				t.Logf("deleting %s folder", project)
				output, err := linux_util.ExecuteCmd(fmt.Sprintf("rm -rf %s", project))
				t.Logf("command executed: rm -rf %s. output %s", project, output)
				if err != nil {
					t.Error(fmt.Errorf("error while deleting project files %s: %w: %s", project, err, output))
					t.FailNow()
				}
			}

			t.Logf("unzipping file %s", zipFile)
			output, err = linux_util.ExecuteCmd(fmt.Sprintf("unzip %s -d %s", zipFile, rootDir))
			t.Logf("command executed: unzip %s. output %s", zipFile, output)
			if err != nil {
				t.Error(fmt.Errorf("error while unzip accelerator project zip file %s: %w: %s", zipFile, err, output))
				t.FailNow()
			}
			t.Logf("Accelerator project zip files %s unzipped successfully", zipFile)

			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppBuildStatus(t *testing.T, name string, buildNameSuffix string, namespace string) features.Feature {
	return features.New("verify-builds").
		Assess("verify-build-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify build status")
			buildName = fmt.Sprintf("%s%s", name, buildNameSuffix)
			status := kubectl_helpers.VerifyBuildStatus(buildName, namespace, 10, 30)
			t.Logf("Build status is : %t", status)
			if !status {
				t.Error(fmt.Errorf("build is not ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppImagesKpacStatus(t *testing.T, namespace string) features.Feature {
	return features.New("verify-images.kpac").
		Assess("verify-images.kpac-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify latest image status")
			status := kubectl_helpers.GetLatestImageStatus("", namespace)
			t.Logf("Image status is: %s", status)
			if status != "True" {
				t.Error(fmt.Errorf("image is not built/ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppPodIntentStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-podintents-labels-conventions").
		Assess("verify-podintent-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying podintent ready status")

			// check
			if !kubectl_helpers.VerifyPodIntentStatus(name, namespace, 5, 30) {
				t.Error("podintent not ready")
				t.FailNow()
			} else {
				t.Log("podintent ready")
			}
			return ctx
		}).
		Assess("verify-podintent-alv-lables", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying appliveview labels present in podintent")

			// check
			alvLabelsPresent := kubectl_helpers.ValidateAppLiveViewLabels(name, namespace)
			if !alvLabelsPresent {
				t.Error("appliveview lables absent in podintent")
				t.FailNow()
			} else {
				t.Log("appliveview labels present in podintent")
			}
			return ctx
		}).
		Assess("verify-podintent-springbootconventions-lables", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying springbootconventions labels present in podintent")

			// check
			springbootconventionsLabelsPresent := kubectl_helpers.ValidateSpringBootLabels(name, namespace)
			if !springbootconventionsLabelsPresent {
				t.Error("springbootconventions lables absent in podintent")
				t.FailNow()
			} else {
				t.Log("springbootconventions labels present in podintent")
			}
			return ctx
		}).
		Assess("verify-podintent-alv-conventions", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying appliveview conventions present in podintent")

			// check
			appliveviewConventionsPresent := kubectl_helpers.ValidateAppLiveViewConventions(name, namespace)
			if !appliveviewConventionsPresent {
				t.Error("appliveview conventions absent in podintent")
				t.FailNow()
			} else {
				t.Log("appliveview conventions present in podintent")
			}
			return ctx
		}).
		Assess("verify-pod-intent-devloper-conventions-annotations", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify if devloper-conventions annotations are added to podintent")
			status := kubectl_helpers.ValidateDeveloperConventions(name, namespace)
			t.Logf("devloper-conventions annotations status is : %t", status)
			if !status {
				t.Error(fmt.Errorf("devloper-conventions annotations are not added to the podintent"))
				t.FailNow()
			}
			return ctx
		}).
		Assess("verify-podintent-springbootconventions-conventions", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying springbootconventions conventions present in podintent")

			// check
			springbootconventionsConventionsPresent := kubectl_helpers.ValidateSpringBootConventions(name, namespace)
			if !springbootconventionsConventionsPresent {
				t.Error("springbootconventions conventions absent in podintent")
				t.FailNow()
			} else {
				t.Log("springbootconventions conventions present in podintent")
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppImageRepositoryDelivery(t *testing.T, name string, imageDeliverySuffix string, namespace string) features.Feature {
	return features.New("verify-image-repository-delivery").
		Assess("verify-image-repositories", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify image-repositories-delivery status")
			imageRepo := name + imageDeliverySuffix
			status := kubectl_helpers.VerifyImageRepositoryStatus(imageRepo, namespace, 10, 30)
			t.Logf("ImageRepository %s status is : %t", imageRepo, status)
			if !status {
				t.Error(fmt.Errorf("imageRepository %s is not ready", imageRepo))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppRevisionStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-revision-status").
		Assess("verify-revision-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying revision ready status")

			revisionName = kubectl_helpers.GetLatestRevision(name, namespace, 1, 30)
			t.Logf("latestRevision set to %s", revisionName)
			revisionReady := kubectl_helpers.ValidateRevisionStatus(revisionName, name, namespace, 5, 30)

			if !revisionReady {
				t.Error("revision not ready")
				t.FailNow()
			} else {
				t.Log("revision ready")
			}
			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppKsvcStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-ksvc-status").
		Assess("verify-ksvc-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying ksvc ready status %s", ksvcLatestReady)

			ksvcReady := kubectl_helpers.VerifyKsvcStatus(name, namespace, revisionName, 5, 30)
			if !ksvcReady {
				t.Error("ksvc not ready")
				t.FailNow()
			} else {
				t.Log("ksvc ready")
			}

			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppResponseBeforeChange(t *testing.T, workloadUrl string, originalString string, namespace string) features.Feature {
	return features.New("verify-app-response").
		Assess("get-externalip-and-check-webpage-for-string", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("getting external ip and checking for string")

			// get external IP
			url, err := client.GetServiceExternalIP("envoy", "tanzu-system-ingress", cfg.Client().RESTConfig(), 2, 30)
			if err != nil {
				t.Error("error while getting external IP")
				t.Fail() // DON'T DO t.FailNow() AS WE WANT TO CLEAN UP REGARDLESS OF THE STATE OF THE TEST
			} else {
				t.Log("external IP retrieved")
			}

			// set url
			if !strings.HasPrefix(url, "http://") {
				url = "http://" + url
			}

			webpageContainsString, _ := misc.VerifyWebpageContainsString(workloadUrl, url, originalString, 10, 10, 30)
			if !webpageContainsString {
				t.Error("webpage does not contains string")
				t.Fail() // DON'T DO t.FailNow() AS WE WANT TO CLEAN UP REGARDLESS OF THE STATE OF THE TEST
			} else {
				t.Log("webpage contains string")
			}

			return ctx
		}).
		Feature()
}

func VerifyTanzuJavaWebAppDeliverable(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-deliverables").
		Assess("verify-deliverables-ready", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying deliverables ready status")
			if !kubectl_helpers.ValidateDeliverables(name, namespace, 5, 30) {
				t.Error("deliverables not ready")
				t.FailNow()
			} else {
				t.Log("deliverables ready")
			}
			return ctx
		}).
		Feature()
}

func VerifySourceScanStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-source-scan-status").
		Assess("verify-source-scan-completed", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying source scan status")

			// check
			sourceScanCompleted := kubectl_helpers.ValidateSourceScans(name, namespace, 5, 30)
			if !sourceScanCompleted {
				t.Log("source scan completed")
				// t.FailNow()
			} else {
				t.Log("source scan completed successfully")
			}

			return ctx
		}).
		Feature()
}

func VerifyImageScanStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-imagescan-status").
		Assess("verify-imagescan-completed", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("verifying image scan status")

			// check
			imageScanCompleted := kubectl_helpers.ValidateImageScans(name, namespace, 5, 30)
			if !imageScanCompleted {
				t.Error("image scan failed")
				t.FailNow()
			} else {
				t.Log("image scan completed successfully")
			}

			return ctx
		}).
		Feature()
}

func ProcessDeliverable(t *testing.T, name string, namespace string, buildContext string, runContext string, targetRepo string) features.Feature {
	return features.New("getting deliverable and changing file").
		Assess(fmt.Sprintf("getting deliverable file %s", name), func(ctx context.Context, t *testing.T, c *envconf.Config) context.Context {
			// changing to build cluster
			_, err := kubectl_libs.UseContext(buildContext)
			if err != nil {
				t.Errorf("error while changing context to %s", buildContext)
				t.FailNow()
			} else {
				t.Logf("context changed to %s", buildContext)
			}

			valid := kubectl_helpers.ValidateBuildClusterDeliverableStatus(name, namespace, 5, 5)
			if !valid {
				t.Errorf("error while getting deliverable %s", name)
				t.FailNow()
			} else {
				t.Logf("validated deliverable %s success", name)
				deliverable := kubectl_libs.GetDeliverablesYaml(name, namespace)
				if targetRepo != "" {
					sourceImage := kubectl_libs.GetDeliverables(name, namespace)[0].SOURCE
					imageTag := strings.Split(sourceImage, ":")[1]
					newSourceImage := fmt.Sprintf("%s:%s", targetRepo, imageTag)
					deliverable.Spec.Source.Image = newSourceImage
				}
				deliverable.Status = kubectl_libs.Status{}
				deliverable.Metadata.OwnerReferences = kubectl_libs.OwnerReferences{}
				// create temporary deliverable file
				t.Log("creating tempfile for deliverable manifest")
				tempFile, err := ioutil.TempFile("", "deliverable*.yaml")
				if err != nil {
					t.Error("error while creating tempfile for deliverable manifest")
					t.FailNow()
				} else {
					t.Log("created tempfile")
				}
				defer os.Remove(tempFile.Name())

				// write the updated manifest to the temporary file
				err = utils.WriteYAMLFile(tempFile.Name(), deliverable)
				if err != nil {
					t.Error("error while writing updated deliverable manifest to YAML file")
					t.FailNow()
				} else {
					t.Log("wrote deliverable manifest to file")
				}

				// changing to run cluster
				_, err = kubectl_libs.UseContext(runContext)
				if err != nil {
					t.Errorf("error while changing context to %s", runContext)
					t.FailNow()
				} else {
					t.Logf("context changed to %s", runContext)
				}

				t.Log("generated deliverable.yaml to be applied :")
				linux_util.ExecuteCmd(fmt.Sprintf("cat %s", tempFile.Name()))

				//deploying deliverable
				err = kubectl_libs.KubectlApplyConfiguration(tempFile.Name(), namespace)
				if err != nil {
					t.Error("error deploying deliverable")
					t.FailNow()
				} else {
					t.Log("deployed deliverable")
				}
			}
			return ctx
		}).Feature()
}

func ValidateListofInstalledPackage(t *testing.T, namespace string, expectedList []string) features.Feature {
	return features.New("validation-of-installed-package").
		Assess(fmt.Sprintf("validation-of-installed-packages-in-%s", namespace), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			var installedPackagesList []string
			installedPackages := tanzu_libs.ListInstalledPackages(namespace)
			for index, _ := range installedPackages {
				installedPackagesList = append(installedPackagesList, installedPackages[index].NAME)
			}
			fmt.Printf("installedPackagesList: %+v\n", installedPackagesList)
			sort.Strings(expectedList)
			sort.Strings(installedPackagesList)
			fmt.Println("Expected Packages List : ", expectedList)
			fmt.Println("Installed Packages List : ", installedPackagesList)
			same := true
			if len(expectedList) != len(installedPackagesList) {
				same = false
				fmt.Println("Expected list and installedPackagesList are not same")
			} else {

				for index, value := range expectedList {
					if value != installedPackagesList[index] {
						same = false
						break
					}
				}
				fmt.Println(same)
			}
			if !same {
				fmt.Printf("Extra packages in validation list: %+v\n", linux_util.ArrayDifference(expectedList, installedPackagesList))
				fmt.Printf("Missing packages from validation list: %+v\n", linux_util.ArrayDifference(installedPackagesList, expectedList))
				t.FailNow()
			}
			log.Println("Validation passed")
			return ctx
		}).
		Feature()
}

func VerifyRabbitmqClustersStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-rabbitmqclusters").
		Assess("verify-rabbitmq-cluster-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying rabbitmq-cluster-status")
			status := kubectl_helpers.VerifyRabbitmqClustersStatus(name, namespace, 15, 30)
			t.Logf("Rabbitmq Cluster status is : %t", status)
			if !status {
				t.Error(fmt.Errorf("Rabbitmq Cluster is not ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func ServiceInstanceList(t *testing.T, namespace string) features.Feature {
	return features.New("service-instance-list").
		Assess("service-instance-list", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("service-instance-list")
			listofServiceInstances := tanzu_libs.ListServiceInstances(namespace)
			fmt.Printf("listofServiceInstances: %+v\n", listofServiceInstances)
			service_ref = listofServiceInstances[0].SERVICE_REF
			t.Logf("service_ref is : %s", service_ref)
			return ctx
		}).
		Feature()
}

func ServiceTypeList(t *testing.T) features.Feature {
	return features.New("service-type-list").
		Assess("service-instance-list", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("service-instance-list")
			listofServiceTypes := tanzu_libs.ListServiceTypes()
			fmt.Printf("listofServiceTypes: %+v\n", listofServiceTypes)
			return ctx
		}).
		Feature()
}

func CreateServiceClaim(t *testing.T, resourceNamespace string) features.Feature {
	return features.New("create-service-claim").
		Assess("create-service-claim", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("Create service claim")
			listofServiceTypes := tanzu_libs.ListServiceTypes()
			resourceName := serviceInstanceName
			resourceKind := listofServiceTypes[0].KIND
			resourceApiVersion := listofServiceTypes[0].APIVERSION
			status := tanzu_libs.CreateServiceClaim(serviceInstanceName, resourceName, resourceNamespace, resourceKind, resourceApiVersion, "")
			if !status {
				t.Error("error while creating service claim")
				t.FailNow()
			} else {
				t.Logf("Service claim %s Created", serviceInstanceName)
			}
			return ctx
		}).
		Feature()
}

func ServiceTypeListWithWide(t *testing.T) features.Feature {
	return features.New("service-claim-list").
		Assess("service-claim-list", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("service-claim-list")
			listofServiceClaims := tanzu_libs.ListServiceClaimithWide()
			fmt.Printf("listofServiceClaims: %+v\n", listofServiceClaims)
			db_ref = listofServiceClaims[0].CLAIM_REF
			return ctx
		}).
		Feature()
}

func CreateServiceClaimWithInput(t *testing.T, name string, resourceName string, resourceNamespace string, resourceKind string, resourceApiVersion string) features.Feature {
	return features.New("create-service-claim").
		Assess("create-service-claim", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Log("Create service claim")
			status := tanzu_libs.CreateServiceClaim(name, resourceName, resourceNamespace, resourceKind, resourceApiVersion, "")
			if !status {
				t.Error("error while creating service claim")
				t.FailNow()
			} else {
				t.Logf("Service claim %s Created", name)
			}
			return ctx
		}).
		Feature()
}

func VerifyServiceClaimStatus(t *testing.T, name string) features.Feature {
	return features.New("verify-ServiceClaimStatus").
		Assess("verify-ServiceClaimStatus", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying service-claim-status")
			status := tanzu_helpers.VerifyServiceClaimStatus(name, 5, 30)
			t.Logf("ServiceClaimStatus : %t", status)
			if !status {
				t.Error(fmt.Errorf("ServiceClaimStatus is not ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func GetServiceClaimInfo(t *testing.T, namespace string) features.Feature {
	return features.New("get-claim-info").
		Assess("Getting-service-claim-info", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("Getting service claim info")
			claimReference, err := tanzu_libs.GetServiceClaimInfo(serviceInstanceName, namespace)

			if err != nil {
				t.Error("error while Getting service claim reference")
				t.FailNow()
			} else {
				t.Logf("service claim reference is %s for service claim %s", claimReference, serviceInstanceName)
			}

			return ctx
		}).
		Feature()
}

func TanzuDeleteServiceClaim(t *testing.T, name string, namespace string) features.Feature {
	return features.New("delete-service-claim").
		Assess(fmt.Sprintf("delete-service-claim-%s", name), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deleting service claim %s", name)
			// deploy app
			err := tanzu_libs.DeleteServiceClaim(name, namespace)
			if err != nil {
				t.Errorf("error while deleting service claim %s", name)
				t.FailNow()
			} else {
				t.Logf("deleted service claim %s", name)
			}

			return ctx
		}).
		Feature()
}

func TanzuCreateWorkloadWithGitRepo(t *testing.T, workloadName string, workloadGitRepo string, namespace string) features.Feature {
	return features.New("create-tanzu-workload-via-gitrepo").
		Assess(fmt.Sprintf("create-tanzu-workload-via-gitrepo-from-%s", workloadGitRepo), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying workload %s in namespace %s", workloadName, namespace)
			//workloadFilePath := filepath.Join(rootDir, workloadYamlFile)
			// deploy app
			service_ref = "rmq=" + service_ref
			err := tanzu_libs.TanzuCreateWorkloadWithGitRepo(workloadName, workloadGitRepo, "main", "tap-1.0", service_ref, namespace)
			if err != nil {
				t.Errorf("error while deploying workload %s", workloadName)
				t.FailNow()
			} else {
				t.Logf("deployed workload %s in %s", workloadName, namespace)
			}

			return ctx
		}).
		Feature()
}

func TanzuCreateWorkloadWithSubPath(t *testing.T, workloadName string, subPath string, sourceImage string, localPath string, namespace string) features.Feature {
	return features.New("create-tanzu-workload-via-subpath").
		Assess(fmt.Sprintf("create-tanzu-workload-via-subpath-from-%s", subPath), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying workload %s in namespace %s", workloadName, namespace)
			err := tanzu_libs.TanzuCreateWorkloadWithSubPath(workloadName, subPath, sourceImage, localPath, namespace)
			if err != nil {
				t.Errorf("error while deploying workload %s", workloadName)
				t.FailNow()
			} else {
				t.Logf("deployed workload %s in %s", workloadName, namespace)
			}

			return ctx
		}).
		Feature()
}

func TanzuUpdateWorkloadWithSubPath(t *testing.T, workloadName string, subPath string, sourceImage string, localPath string, namespace string) features.Feature {
	return features.New("update-tanzu-workload-via-subpath").
		Assess(fmt.Sprintf("update-tanzu-workload-via-subpath-from-%s", subPath), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("updating workload %s in namespace %s", workloadName, namespace)
			err := tanzu_libs.TanzuUpdateWorkloadWithSubPath(workloadName, subPath, sourceImage, localPath, namespace)
			if err != nil {
				t.Errorf("error while deploying workload %s", workloadName)
				t.FailNow()
			} else {
				t.Logf("deployed workload %s in %s", workloadName, namespace)
			}

			return ctx
		}).
		Feature()
}

func TanzuCreateWorkloadWithDBRef(t *testing.T, workloadName string, workloadGitRepo string, namespace string) features.Feature {
	return features.New("create-tanzu-workload-via-gitrepo").
		Assess(fmt.Sprintf("create-tanzu-workload-via-gitrepo-from-%s", workloadGitRepo), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("deploying workload %s in namespace %s", workloadName, namespace)
			//workloadFilePath := filepath.Join(rootDir, workloadYamlFile)
			// deploy app
			db_ref = "db=" + db_ref
			err := tanzu_libs.TanzuCreateWorkloadWithGitRepo(workloadName, workloadGitRepo, "main", "tap-1.0", db_ref, namespace)
			if err != nil {
				t.Errorf("error while deploying workload %s", workloadName)
				t.FailNow()
			} else {
				t.Logf("deployed workload %s in %s", workloadName, namespace)
			}

			return ctx
		}).
		Feature()
}

func UpdateDomainRecords(t *testing.T) features.Feature {

	return features.New("update-domain-records").
		Assess("update-domain-records", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {

			envoyExternalIP := kubectl_helpers.GetServiceExternalIP("envoy", "tanzu-system-ingress", 2, 30)
			clusterConfig := kubectl_libs.GetCurrentContext()
			// route 53 related changes - only for public clouds (AKS,EKS,GKE,ARO)
			val, present := os.LookupEnv("TKGM")
			if !present {
				route53File := filepath.Join(suiteResourcesDir, "aws-record-set.json")
				utils.ReplaceStringInFile(route53File, "<ENVOY-LB-IP>", envoyExternalIP)
				if strings.Contains(clusterConfig, "aws:eks") {
					utils.ReplaceStringInFile(route53File, "<TYPE>", "CNAME")
				} else {
					utils.ReplaceStringInFile(route53File, "<TYPE>", "A")
				}
				cmd := fmt.Sprintf("aws route53 change-resource-record-sets --hosted-zone-id Z01910001Y8J4230PVYZQ --change-batch file://%s --profile svc.tapdemo-user-concourse-assume-role", route53File)
				linux_util.ExecuteCmdInBashMode(cmd)
			}

			// domain entry for TKGM cluster
			if present && val == "true" {
				clusterName := strings.Split(clusterConfig, "@")[1]
				dnsServerKeyFile := filepath.Join(suiteResourcesDir, "dns-server.key")
				cmd := fmt.Sprintf("ssh -o StrictHostKeyChecking=no -i %s dap-ops@10.221.46.1 'sudo -S bash /root/update-dns.sh *.%s %s < /home/dap-ops/.dap-passwd'", dnsServerKeyFile, clusterName, envoyExternalIP)
				linux_util.ExecuteCmdInBashMode(cmd)
			}
			return ctx
		}).Feature()

}

func CreateNamespace(t *testing.T, namespace string) features.Feature {
	return features.New("create namespace").
		Assess(fmt.Sprintf("Create namespace %s", namespace), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {

			err := kubectl_libs.KubectlCreateNamespace(namespace)
			if err != nil {
				t.Errorf("error while creating namespace %s", namespace)
				t.FailNow()
			} else {
				t.Logf("created %s", namespace)
			}
			return ctx
		}).Feature()
}

func CreateNamespacesIfNotExistst(t *testing.T, namespace string) features.Feature {
	return features.New("create namespace").
		Assess(fmt.Sprintf("Create namespace %s", namespace), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {

			err := kubectl_libs.KubectlCreateNamespaceIfNotExists(namespace)
			if err != nil {
				t.Errorf("error while creating namespace %s", namespace)
				t.FailNow()
			} else {
				t.Logf("created %s", namespace)
			}
			return ctx
		}).Feature()
}

func DeleteNamespace(t *testing.T, namespace string, clusterContext string) features.Feature {
	return features.New("delete namespace").
		Assess(fmt.Sprintf("delete namespace %s", namespace), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			if clusterContext != " " {
				_, err := kubectl_libs.UseContext(clusterContext)
				if err != nil {
					t.Errorf("error while changing context to %s", clusterContext)
					t.FailNow()
				} else {
					t.Logf("context changed to %s", clusterContext)
				}
			}

			err := kubectl_libs.KubectlDeleteNamespace(namespace)
			if err != nil {
				t.Errorf("error while deleting to %s", namespace)
				t.FailNow()
			} else {
				t.Logf("deleted %s", namespace)
			}
			return ctx
		}).Feature()
}

func DeleteNamespaceIfExists(t *testing.T, namespace string, clusterContext string) features.Feature {
	return features.New("delete namespace").
		Assess(fmt.Sprintf("delete namespace %s", namespace), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			if clusterContext != " " {
				_, err := kubectl_libs.UseContext(clusterContext)
				if err != nil {
					t.Errorf("error while changing context to %s", clusterContext)
					t.FailNow()
				} else {
					t.Logf("context changed to %s", clusterContext)
				}
			}

			err := kubectl_libs.KubectlDeleteNamespaceIfExists(namespace)
			if err != nil {
				fmt.Println(err)
				t.Errorf("error while deleting to %s", namespace)
				t.FailNow()
			} else {
				t.Logf("deleted %s", namespace)
			}
			return ctx
		}).Feature()
}

func ListAllBuilds(t *testing.T, namespace string) features.Feature {
	return features.New("list-all-builds").
		Assess("list-builds", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			kubectl_libs.GetBuilds("", namespace)
			return ctx
		}).Feature()
}

func InstallIndividualPackage(t *testing.T, name string, packageName string, namespace string, valuesFile string, pollTimeout string) features.Feature {
	return features.New("install individual package").
		Assess(fmt.Sprintf("install individual package %s", packageName), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("Installing package: %s", packageName)
			availablePkgs := tanzu_libs.ListAvailablePackages(packageName, namespace)
			t.Logf("package name: %s, version: %s", packageName, availablePkgs[0].VERSION)
			tanzu_libs.InstallPackage(name, packageName, availablePkgs[0].VERSION, namespace, valuesFile, pollTimeout)
			installed := tanzu_helpers.ValidateInstalledPackageStatus(name, namespace, 5, 30)
			if installed {
				t.Logf("Installed package : %s, version: %s successfully", name, availablePkgs[0].VERSION)
			} else {
				t.Error(fmt.Errorf("Installation FAILED for package : %s, version: %s", name, availablePkgs[0].VERSION))
				t.Fail()
			}
			return ctx
		}).Feature()
}

func LinkCluster(t *testing.T, context1 string, context2 string) features.Feature {
	return features.New("linking-clusters").
		Assess(fmt.Sprintf("link cluster-%s-and-%s", context1, context2), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("linking-clusters %s and %s", context1, context2)
			err := kubectl_libs.LinkClusterWithSCP(context1, context2)
			if err != nil {
				t.Errorf("error while linking clusters")
				t.FailNow()
			} else {
				t.Logf("cluster linked")
			}

			return ctx
		}).
		Feature()
}

func ListInstalledOperator(t *testing.T, name string) features.Feature {
	return features.New("list-installed-operator").
		Assess("list-installed-operator", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			kubectl_libs.GetInstalledOpearator(name)
			return ctx
		}).Feature()
}

func FedrateCluster(t *testing.T, context1 string, context2 string, namespace string, apiGroup string, apiVersion string, apiResource string) features.Feature {
	return features.New("fedrate-clusters").
		Assess(fmt.Sprintf("fedrate-cluster-%s-and-%s", context1, context2), func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("Fedrate-clusters %s and %s", context1, context2)
			err := kubectl_libs.FedrateCluster(context1, context2, namespace, apiGroup, apiVersion, apiResource)
			if err != nil {
				t.Errorf("error while Fedrating clusters")
				t.FailNow()
			} else {
				t.Logf("cluster Fedrated")
			}

			return ctx
		}).
		Feature()
}

func GetApiResources(t *testing.T) features.Feature {
	return features.New("api-resources-list").
		Assess("list-api-resources", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			err := kubectl_libs.GetApiResource()
			if err != nil {
				t.Errorf("error while getting api resources")
				t.FailNow()
			} else {
				t.Logf("API Resources present")
			}

			return ctx
		}).Feature()
}

func ServiceClassesList(t *testing.T) features.Feature {
	return features.New("listofServiceClasses").
		Assess("service-class-list", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("service-class-list")
			listofServiceClasses := tanzu_libs.ListServiceClasses()
			fmt.Printf("listofServiceClasses: %+v\n", listofServiceClasses)
			return ctx
		}).
		Feature()
}

func VerifyRabbitmqClustersResources(t *testing.T, file string, namespace string) features.Feature {
	return features.New("verify-rabbitmqcluster-resources").
		Assess("verify-rabbitmq-cluster-resources", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying rabbitmq-cluster-resource")
			status := kubectl_helpers.VerifyRabbitmqClusterResource(file, namespace, 10, 30)
			t.Logf("Rabbitmq Cluster resoucrce is : %t", status)
			if !status {
				t.Error(fmt.Errorf("Rabbitmq Cluster respurce status is not ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyPodStatus(t *testing.T, namespace string) features.Feature {
	return features.New("verify-pod-status").
		Assess("verify-pod-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verifying pod status")
			status := kubectl_helpers.VerifyPodStatus(namespace)
			t.Logf("pod status is : %t", status)
			if !status {
				t.Error(fmt.Errorf("pods are ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func VerifyImagesKpacStatus(t *testing.T, name string, namespace string) features.Feature {
	return features.New("verify-images.kpac").
		Assess("verify-images.kpac-status", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			t.Logf("verify latest image status")
			status := kubectl_helpers.GetWorkloadLatestImageStatus(name, namespace)
			t.Logf("Image status is: %s", status)
			if status != "True" {
				t.Error(fmt.Errorf("image is not built/ready"))
				t.Fail()
			}
			return ctx
		}).
		Feature()
}

func UpdateStringInFile(t *testing.T, originalString string, newString string, filePath string) features.Feature {
	return features.New("replace-string-in-file").
		Assess("replace-tanzu-to-tap ", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			oldString := originalString
			newString := newString
			filePath := filepath.Join(rootDir, filePath)
			t.Logf("Replace from string %s to string %s in file %s", oldString, newString, filePath)
			err := utils.ReplaceStringInFile(filePath, oldString, newString)
			if err != nil {
				t.Error(fmt.Errorf("error while replacing string in file %s : %w", filePath, err))
				t.FailNow()
			}
			return ctx
		}).
		Feature()
}

func UpdateTapValuesWithMaven(t *testing.T, name string, tapPackageName string, tapVersion string, profile string, supplyChain string, namespace string, pollTimeout string, viewContext string, buildContext string, mavenBranchURL string) features.Feature {
	return features.New("update-tap-profile-metadata-store-scanning").
		Assess("update-package", func(ctx context.Context, t *testing.T, cfg *envconf.Config) context.Context {
			var tapValuesSchema models.TapValuesSchema
			tapValuesSchema, err := models.GetProfileTapValuesSchema("build")
			if err != nil {
				t.Error("error while getting tap values schema")
				t.FailNow()
			}
			t.Log(tapValuesSchema)

			tapValuesSchema.Profile = profile
			tapValuesSchema.SupplyChain = supplyChain
			tapValuesSchema.OotbSupplyChainBasic.Maven.Repository.URL = mavenBranchURL
			tapValuesSchema.OotbSupplyChainBasic.Maven.Repository.SecretName = "maven-credentials"

			err = tanzu_helpers.UpdateTapValues(tapValuesSchema, name, tapPackageName, tapVersion, namespace)
			if err != nil {
				t.Error("error while updating tap values")
			}
			updated := tanzu_helpers.ValidateInstalledPackageVersion(name, namespace, tapVersion, 30, 60)
			if updated {
				t.Logf("Updated tap version: %s successfully", tapVersion)
			} else {
				t.Error(fmt.Errorf("update FAILED for tap version: %s", tapVersion))
				t.Fail()
			}
			log.Printf("final packages version after tap update...")
			tanzu_libs.ListInstalledPackages(namespace)
			return ctx
		}).
		Feature()
}
