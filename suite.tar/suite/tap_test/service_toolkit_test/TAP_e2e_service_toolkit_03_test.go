//go:build all || service_toolkit || service_toolkit_outside_cluster

package service_toolkit_test

import (
	"testing"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"path/filepath"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils"
)

func TestServicetoolkitOutsideCluster(t *testing.T) {
	t.Log("************** TestCase START: TestServicetoolkitOutsideCluster **************")
	external_azure_db_binding_compatible_file := filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "external-azure-db-binding-compatible.yaml")
	developerNamespaceFile:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/suite"), "developer-namespace.yaml")
	testenv.Test(t,
		//Create a Create a Kubernetes Secret resource
		common_features.ApplyKubectlConfigurationFile(t, external_azure_db_binding_compatible_file, "default"),

		common_features.CreateServiceClaimWithInput(t, "external-azure-db-claim", "external-azure-db-binding-compatible", "","Secret", "v1"),

		common_features.ServiceTypeListWithWide(t),

		// create secrets in default
		common_features.CreateSecret(t, suiteConfig.TapRegistrySecret.Name, suiteConfig.TapRegistrySecret.Registry, suiteConfig.TapRegistrySecret.Username, suiteConfig.TapRegistrySecret.Password, "string", "default", suiteConfig.TapRegistrySecret.Export),
		common_features.CreateSecret(t,  suiteConfig.RegistryCredentialsSecret.Name, suiteConfig.RegistryCredentialsSecret.Registry, suiteConfig.RegistryCredentialsSecret.Username, suiteConfig.RegistryCredentialsSecret.Password, "string", "default", suiteConfig.RegistryCredentialsSecret.Export),
		common_features.ApplyKubectlConfigurationFile(t, developerNamespaceFile, "default"),

		// // Create workload
		common_features.TanzuCreateWorkloadWithDBRef(t, suiteConfig.ServiceToolkit.WorkloadName, suiteConfig.ServiceToolkit.SpringPetclinicWorkloadRepo, "default"),
		common_features.VerifyBuildStatus(t, suiteConfig.ServiceToolkit.WorkloadName, suiteConfig.ServiceToolkit.BuildNameSuffix, "default"),
		common_features.VerifyRevisionStatus(t, suiteConfig.ServiceToolkit.WorkloadName, "default"),
		common_features.VerifyKsvcStatus(t, suiteConfig.ServiceToolkit.WorkloadName, "default"),
		common_features.GetKsvcUrl(t, suiteConfig.ServiceToolkit.WorkloadName, "default"),
		common_features.VerifyWorkloadResponse(t, suiteConfig.ServiceToolkit.DefaultWorkloadURL, "Welcome", ""),
		common_features.TanzuDeleteWorkload(t, suiteConfig.ServiceToolkit.WorkloadName, "default"),

	)
	t.Log("************** TestCase END: TestServicetoolkitOutsideCluster **************")
}
