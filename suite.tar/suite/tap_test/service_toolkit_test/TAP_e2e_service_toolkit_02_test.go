//go:build all || service_toolkit || service_toolkit_diff_namespace

package service_toolkit_test

import (
	"testing"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/tap_test/common_features"
	"path/filepath"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils"
)

func TestServicetoolkitDiffNamespace(t *testing.T) {
	t.Log("************** TestCase START: TestServicetoolkitDifferentNamespace **************")
	resource_claims_and_rbac_rmq_file:= filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "resource-claims-rmq.yaml")
	rabbitmq_cluster_service_instance_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "rmq-1-service-instance.yaml")
	resource_claims_cross_namepace_policy_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "rmq-claim-policy.yaml")
	developerNamespaceFile:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/suite"), "developer-namespace.yaml")
	consumer_workload_yaml_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "spring-sensors-consumer-web.yaml")
	producer_workload_yaml_file:=filepath.Join(filepath.Join(utils.GetFileDir(), "../../resources/service_toolkit"), "spring-sensors-producer.yaml")
	testenv.Test(t,
		common_features.InstallAndDeployRmqOperator(t, suiteConfig.ServiceToolkit.Name, suiteConfig.ServiceToolkit.Gitrepository),
		common_features.ApplyKubectlConfigurationFile(t, resource_claims_and_rbac_rmq_file, "default"),

		// Create a service-instances Namespace and Rabbitmq instance
		common_features.CreateNamespace(t, "service-instances"),
		common_features.ApplyKubectlConfigurationFile(t, rabbitmq_cluster_service_instance_file, "service-instances"),

		common_features.VerifyRabbitmqClustersStatus(t, "", "service-instances"),
		// // Apply Cross namespace policy
		common_features.ApplyKubectlConfigurationFile(t, resource_claims_cross_namepace_policy_file, "service-instances"),
		common_features.ServiceInstanceList(t,"service-instances"),

		// Create Service Claim
		common_features.ServiceTypeList(t),
		common_features.CreateServiceClaim(t, "service-instances"),

		common_features.CreateSecret(t, suiteConfig.TapRegistrySecret.Name, suiteConfig.TapRegistrySecret.Registry, suiteConfig.TapRegistrySecret.Username, suiteConfig.TapRegistrySecret.Password, "string", "default", suiteConfig.TapRegistrySecret.Export),
		common_features.CreateSecret(t,  suiteConfig.RegistryCredentialsSecret.Name, suiteConfig.RegistryCredentialsSecret.Registry, suiteConfig.RegistryCredentialsSecret.Username, suiteConfig.RegistryCredentialsSecret.Password, "string", "default", suiteConfig.RegistryCredentialsSecret.Export),
		common_features.ApplyKubectlConfigurationFile(t, developerNamespaceFile, "default"),

		common_features.VerifyServiceClaimStatus(t, "rmq-1"),
		common_features.GetServiceClaimInfo(t, "default"),

		// Create Consumer and Producer workload 
		common_features.TanzuDeployWorkload(t, consumer_workload_yaml_file, "default"),
		common_features.TanzuDeployWorkload(t, producer_workload_yaml_file, "default"),

		// Verify Consumer Workload
		common_features.VerifyBuildStatus(t, suiteConfig.ServiceToolkit.ConsumerWorkloadName, suiteConfig.ServiceToolkit.BuildNameSuffix,"default"),
		common_features.VerifyRevisionStatus(t, suiteConfig.ServiceToolkit.ConsumerWorkloadName, "default"),
		common_features.VerifyKsvcStatus(t, suiteConfig.ServiceToolkit.ConsumerWorkloadName, "default"),
		common_features.GetKsvcUrl(t, suiteConfig.ServiceToolkit.ConsumerWorkloadName, "default"),

		// Verify Producer workload 
		common_features.VerifyBuildStatus(t, suiteConfig.ServiceToolkit.ProducerWorkloadName, suiteConfig.ServiceToolkit.BuildNameSuffix,"default"),
		common_features.VerifyRevisionStatus(t, suiteConfig.ServiceToolkit.ProducerWorkloadName, "default"),
		common_features.VerifyKsvcStatus(t, suiteConfig.ServiceToolkit.ProducerWorkloadName, "default"),

		// Verify Response and Cleanup
		common_features.VerifyWorkloadResponse(t, suiteConfig.ServiceToolkit.SensorURL, suiteConfig.ServiceToolkit.SensorMessage, ""),
		common_features.TanzuDeleteWorkload(t, suiteConfig.ServiceToolkit.ConsumerWorkloadName, "default"),
		common_features.TanzuDeleteWorkload(t, suiteConfig.ServiceToolkit.ProducerWorkloadName, "default"),
		common_features.TanzuDeleteServiceClaim(t, "rmq-1", "default"),
		common_features.DeleteApp(t, suiteConfig.ServiceToolkit.Name),
	)
	t.Log("************** TestCase END: TestServicetoolkitDifferentNamespace **************")
}
