package tanzu_libs

// Usage:
//   tanzu accelerator [command]

// Aliases:
//   accelerator, acc

// Available Commands:
//   create        Create a new accelerator
//   delete        Delete an accelerator
//   generate      Generate project from accelerator
//   get           Get accelerator info
//   list          List accelerators
//   push          Push local path to source image
//   update        Update an accelerator
