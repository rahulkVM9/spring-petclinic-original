package tanzu_libs

// Usage:
//   tanzu apps cluster-supply-chain [command]

// Aliases:
//   cluster-supply-chain, cluster-supply-chains, clustersupplychain, clustersupplychains

// Available Commands:
//   list        table listing of cluster supply chains
