package tanzu_libs

import (
	"fmt"
	"log"
	"reflect"
	"strings"
	"gitlab.eng.vmware.com/tap/tap-packages/suite/pkg/utils/linux_util"
	"gopkg.in/yaml.v2"
)


type ListServiceInstancesOutput struct {
	NAME, KIND, SERVICE_TYPE, AGE, SERVICE_REF string
}

func ListServiceInstances(namespace string) []ListServiceInstancesOutput {
	serviceInstances := []ListServiceInstancesOutput{}
	cmd := "tanzu service instance list -owide"
	if namespace != "" {
		cmd += fmt.Sprintf(" -n %s", namespace)
	} else {
		cmd += " -A"
	}
	response, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		return serviceInstances
	}

	temp := strings.Split(strings.TrimSuffix(response, "\n"), "\n")
	if len(temp) <= 3 {
		log.Printf("Output : %s", temp[0])
		return serviceInstances
	}

	indexSpans := linux_util.FieldIndicesWithSingleSpace(temp[2])
	headers := linux_util.GetFields(temp[2], indexSpans)

	for index, ele := range headers {
		headers[index] = strings.ReplaceAll(ele, " ", "_")
	}

	for _, element := range temp[3:] {
		words := linux_util.GetFields(element, indexSpans)
		var serviceInstance ListServiceInstancesOutput
		for index, value := range words {
			reflect.ValueOf(&serviceInstance).Elem().FieldByName(headers[index]).SetString(value)
		}
		serviceInstances = append(serviceInstances, serviceInstance)
	}
	fmt.Printf("serviceInstances: %+v\n", serviceInstances)
	return serviceInstances
}

type ListServiceTypesOutput struct {
	NAME, DESCRIPTION, APIVERSION, KIND string
}

func ListServiceTypes() []ListServiceTypesOutput {
	serviceTypes := []ListServiceTypesOutput{}
	cmd := "tanzu service types list"

	response, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		return serviceTypes
	}

	temp := strings.Split(strings.TrimSuffix(response, "\n"), "\n")
	if len(temp) <= 3 {
		log.Printf("Output : %s", temp[0])
		return serviceTypes
	}

	indexSpans := linux_util.FieldIndices(temp[2])
	headers := linux_util.GetFields(temp[2], indexSpans)

	for _, element := range temp[3:] {
		words := linux_util.GetFields(element, indexSpans)
		var serviceType ListServiceTypesOutput
		for index, value := range words {
			reflect.ValueOf(&serviceType).Elem().FieldByName(headers[index]).SetString(value)
		}
		serviceTypes = append(serviceTypes, serviceType)
	}
	fmt.Printf("serviceTypes: %+v\n", serviceTypes)
	return serviceTypes
}

func CreateServiceClaim(name string, resourceName string, resourceNamespace string, resourceKind string, resourceApiVersion string, namespace string) bool {
	cmd:= ""
	if resourceNamespace != ""{
		cmd += fmt.Sprintf("tanzu service claim create %s --resource-name %s --resource-namespace %s --resource-kind %s --resource-api-version %s -n %s", name, resourceName, resourceNamespace, resourceKind, resourceApiVersion, namespace)
	} else {
		cmd += fmt.Sprintf("tanzu service claim create %s --resource-name %s --resource-kind %s --resource-api-version %s", name, resourceName, resourceKind, resourceApiVersion)
	}
	if namespace != "" {
		cmd += fmt.Sprintf(" -n %s", namespace)
	}
	res, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		log.Println("Error while creating Service Claim %s. Error %w, Output %s", name, err, res)
		return false
	}
	log.Printf("Created Service Claim %s  with name %s in rsource namespace: %s kind %s api version %s", name, resourceName, resourceNamespace, resourceKind, resourceApiVersion)
	return true
}

type ListServiceClaimOutput struct {
	NAME, READY, REASON string
}

func ListServiceClaim() []ListServiceClaimOutput {
	serviceClaims := []ListServiceClaimOutput{}
	cmd := "tanzu services claims list"

	response, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		return serviceClaims
	}

	temp := strings.Split(strings.TrimSuffix(response, "\n"), "\n")
	// if len(temp) <= 3 {
	// 	log.Printf("Output : %s", temp[0])
	// 	return serviceClaims
	// }

	header_index := 0
	if len(temp) <= header_index+1 {
		log.Printf("Output : %s", temp[0])
		return serviceClaims
	}

	// indexSpans := linux_util.FieldIndices(temp[2])
	// headers := linux_util.GetFields(temp[2], indexSpans)

	// for _, element := range temp[3:] {
	// 	words := linux_util.GetFields(element, indexSpans)
	// 	var serviceClaim ListServiceClaimOutput
	// 	for index, value := range words {
	// 		reflect.ValueOf(&serviceClaim).Elem().FieldByName(headers[index]).SetString(value)
	// 	}
	// 	serviceClaims = append(serviceClaims, serviceClaim)
	// }
	indexSpans := linux_util.FieldIndices(temp[header_index])
	headers := linux_util.GetFields(temp[header_index], indexSpans)

	for _, element := range temp[header_index+1:] {
		words := linux_util.GetFields(element, indexSpans)
		var serviceClaim ListServiceClaimOutput
		for index, value := range words {
			reflect.ValueOf(&serviceClaim).Elem().FieldByName(headers[index]).SetString(value)
		}
		serviceClaims = append(serviceClaims, serviceClaim)
	}
	fmt.Printf("serviceClaims: %+v\n", serviceClaims)
	return serviceClaims
}

type ListServiceClaimWithWideOutput struct {
	NAME, READY, REASON, CLAIM_REF string
}

func ListServiceClaimithWide() []ListServiceClaimWithWideOutput {
	serviceClaims := []ListServiceClaimWithWideOutput{}
	cmd := "tanzu service claim list -o wide"

	response, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		return serviceClaims
	}
	temp := strings.Split(strings.TrimSuffix(response, "\n"), "\n")
	header_index := 0
	if len(temp) <= header_index+1 {
		log.Printf("Output : %s", temp[0])
		return serviceClaims
	}

	indexSpans := linux_util.FieldIndicesWithSingleSpace(temp[header_index])
	headers := linux_util.GetFields(temp[header_index], indexSpans)

	for index, ele := range headers {
		headers[index] = strings.ReplaceAll(ele, " ", "_")
	}
	fmt.Printf("headers: %s \n", headers)
	for _, element := range temp[header_index+1:] {
		words := linux_util.GetFields(element, indexSpans)
		var serviceClaim ListServiceClaimWithWideOutput
		for index, value := range words {
			reflect.ValueOf(&serviceClaim).Elem().FieldByName(headers[index]).SetString(value)
		}
		serviceClaims = append(serviceClaims, serviceClaim)
	}
	fmt.Printf("serviceClaims: %+v\n", serviceClaims)
	return serviceClaims
}

type ClaimInfo struct {
	Name   string `yaml:"Name"`
	Status struct {
		Ready bool `yaml:"Ready"`
	} `yaml:"Status"`
	Namespace       string `yaml:"Namespace"`
	ClaimReference  string `yaml:"Claim Reference"`
	ResourceToClaim struct {
		Name      string `yaml:"Name"`
		Namespace string `yaml:"Namespace"`
		Group     string `yaml:"Group"`
		Version   string `yaml:"Version"`
		Kind      string `yaml:"Kind"`
	} `yaml:"Resource to Claim"`
}

func GetServiceClaimInfo(name string, namespace string) (string, error) {
	cmd := fmt.Sprintf("tanzu service claims get %s -n %s", name, namespace)
	res, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		log.Print("Error while getting Service Claim %s. Error %w, Output %s", name, err, res)
		return "", err
	}
	claiminfo := ClaimInfo{}
	resb := []byte(res)
	err = yaml.Unmarshal(resb, &claiminfo)
	if err != nil {
		log.Println("Error while getting Service Claim %s. Error %w, Output %s", name, err, res)
		return "", err
	}
	log.Printf("Claim Reference is %s for service claim %s", claiminfo.ClaimReference, name)
	return claiminfo.ClaimReference, nil
}

func DeleteServiceClaim(name string, namespace string) (error) {
	cmd := fmt.Sprintf("tanzu service claims delete %s -y -n %s", name, namespace)
	res, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		log.Print("Error while getting Service Claim %s. Error %w, Output %s", name, err, res)
	}
	return err
}

type ListServiceClassesOutput struct {
	NAME, DESCRIPTION string
}

func ListServiceClasses() []ListServiceClassesOutput {
	serviceClasses := []ListServiceClassesOutput{}
	cmd := "tanzu services classes list"

	response, err := linux_util.ExecuteCmd(cmd)
	if err != nil {
		return serviceClasses
	}

	temp := strings.Split(strings.TrimSuffix(response, "\n"), "\n")
	if len(temp) <= 1 {
		log.Printf("Output : %s", temp[0])
		return serviceClasses
	}

	indexSpans := linux_util.FieldIndices(temp[0])
	headers := linux_util.GetFields(temp[0], indexSpans)

	for _, element := range temp[1:] {
		words := linux_util.GetFields(element, indexSpans)
		var serviceClass ListServiceClassesOutput
		for index, value := range words {
			reflect.ValueOf(&serviceClass).Elem().FieldByName(headers[index]).SetString(value)
		}
		serviceClasses = append(serviceClasses, serviceClass)
	}
	fmt.Printf("serviceClasses: %+v\n", serviceClasses)
	return serviceClasses
}